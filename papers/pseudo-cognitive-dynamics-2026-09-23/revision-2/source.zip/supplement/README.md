# Reproduction supplement

This directory accompanies **Mathematics of Pseudo-Cognitive Dynamics**, revision 2 (23 September 2026). It preserves selected aggregate data, source references, research catalogs, and offline software controls.

**The package supports specified arithmetic and software checks. It is not a fresh language-model benchmark, a complete audit of every research proof, or a new Lean kernel run.**

Revision 2 preserves the historical datasets below. It adds one separately described four-arm T11 study, T12 retrieval diagnostics, current-source software controls, and focused research/theory review under [update_20260923/](update_20260923/README.md). The original 45 contrasts are unchanged; new synthetic controls are not model trials.

## Source revisions

| Source repository | Pinned commit |
|---|---|
| [private-source-repository](https://github.com/private-source-repository/tree/a4c99b43a044c127787c26997ed942f41591aac6) | `a4c99b43a044c127787c26997ed942f41591aac6` |
| [<private-repo>](https://github.com/<private-repo>/tree/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e) | `bcff9346b68959f4cf330fdf9ca0e64a21c77d3e` |
| [yspennstate/math-open-problems](https://github.com/yspennstate/math-open-problems/tree/b4745ece98fa3839cf7afe35d829d08384c815b4) | `b4745ece98fa3839cf7afe35d829d08384c815b4` |

The table above records the historical dataset snapshots. The separately identified revision-two source window is:

| Updated source | Pinned commit |
|---|---|
| [Broad Brain source](https://github.com/<private-repo>/tree/9c754d786b3a0ea4943da0585d1490c13cd9ef99) | `9c754d786b3a0ea4943da0585d1490c13cd9ef99` |
| [Research source](https://github.com/yspennstate/math-open-problems/tree/24597f0dcc3cc32d81fd8f22b13903f636460396) | `24597f0dcc3cc32d81fd8f22b13903f636460396` |

The intake queues were unchanged in the inspected research comparison, so their historical catalogue counts remain at their original snapshot. Publication time and experiment event time remain distinct.

Source maps, catalog rows, and manifests retain file-level locators and available content hashes. The repositories are private; source links require appropriate access. The included data permit the narrower offline checks below.

The paper makes **no claim to have retrieved all repository contents, inspected every historical version, or verified every proof**. “Complete” in the catalog projection's filename means the projection of eight retrieved catalog inputs; it is not a census of all mathematical problems in the repositories.

## File index

| Files | Contents and purpose |
|---|---|
| `daily_usage.tsv` | Exact 32-day machine-wide daily usage aggregate. |
| `half_hour_output_histogram.tsv` | Anonymous output-token amounts and bucket frequencies. |
| `token_summary.json` | Accounting totals, coverage, directory-associated subtotals, and cap summary. |
| `recompute_usage.py` | Standard-library verifier for daily totals and anonymous half-hour calculations. |
| `benchmark_comparisons.csv`, `benchmark_comparisons.json` | 45 comparative rows with endpoints, denominators, comparators, experimental units, source URLs, and caveats. |
| `benchmark_token_costs.csv` | Available operating token and cost records. |
| `benchmark_sources.json`, `benchmark_bib_keys.json` | Source references and manuscript bibliography-key mappings. |
| `recomputed_grade_totals.json` | Selected local recounts of retrieved grade files. |
| `research_catalog_complete_1168_ids.csv` | Final-observed-row projection per recorded identifier, retaining provenance and inherited statuses. |
| `research_catalog_source_records.json` | All 1,391 physical records from the eight retrieved inputs. |
| `research_catalog_bibliographic_records.json` | Associated bibliography records. |
| `research_catalog_manifest.json` | Input paths, blob hashes, counts, and interpretation policies. |
| `research_catalog_validation.json` | Local projection-consistency checks and file hashes; not a mathematical audit. |
| `research_chronology_reviewed_cases.csv` | Reviewed chronology, scope, and dating/status cautions. |
| `research_proofnet_directory_inventory.csv` | 87 top-level ProofNet directories with source references. |
| `research_catalog_findings.md`, `README_RESEARCH_CATALOG.md` | Detailed catalog methods and limitations. |
| `lean_parser_controls_20260923.json`, `lean_controls/` | Local parser/routing results, bundled source, and reproduction instructions. |
| `ab30_repair/` | Historical original/corrected analyzer and fixture; the old whole-file correction is superseded for integration. |
| `update_20260923/benchmarks/` | T11 aggregate scores/counters, T12 source-reported retrieval aggregates, AB30 missing-evidence status, and audit qualifications. |
| `update_20260923/analyzer/` | Current pinned sources, rebased proposed patch/copies, portable synthetic and mocked controls, hashes and actual validation output. |
| `update_20260923/research/` | Updated source locators and exact proof-scope boundaries. |
| `update_20260923/delivery/`, `update_20260923/theory/` | Architecture/source-function findings and reviewed warning-model arguments. |

## 1. Recompute usage aggregates

From this directory, run:

```bash
python recompute_usage.py
```

The script uses Python's standard library. It does not contact a provider or read transcript folders. It verifies the daily file against Git blob `987b9ed700cb7c5adadcae85a7ebe1b703751e04`, validates dates and integer fields, recomputes four token categories and message totals, and checks the anonymous histogram's output sum and 30,000-token cap calculation.

| Quantity | Expected value |
|---|---:|
| Recorded UTC dates | 32 |
| Usage messages | 244,194 |
| Uncached input | 9,932,399 |
| Cache read | 122,293,331,806 |
| Cache creation | 1,517,660,758 |
| Output | 375,282,198 |
| Four-category sum | 124,196,207,161 |
| Recorded half-hour buckets | 18,502 |
| Positive-output buckets | 16,008 |
| Buckets exceeding 30,000 output | 4,230 |

The cap proportions are 22.86239325% of all recorded buckets and 26.42428786% of positive-output buckets. The historical README's 9% statement does not reproduce using these denominators.

The sum of daily active-session counts is **11,944**, not a distinct-session count. Distinct sessions, exact session endpoints, directory attribution, and original message deduplication cannot be reconstructed from these sanitized inputs; the verifier reports that boundary.

The interval is 9 August–9 September 2026 and covers recorded Claude Code activity on one machine. Counts include repeated cached-prefix reads. They are not unique generated text, mathematical knowledge, model training, or invoices.

**No all-time, all-provider, or Math Brain construction-only total is recoverable.** Construction, maintenance, evaluation, research, and other uses are mixed. Directory-associated subtotals are not construction-only lower bounds. Benchmark calls may already be represented in the broader ledger, so adding the two can double count usage.

## 2. Interpret the benchmark inventory

The 45 rows are **45 contrasts or strata, not 45 independent trials**. Rows can reuse banks, agents, controls, or grading versions. Do not sum their denominators or pool them into a grand “Math Brain accuracy.”

The comparison files retain `id`, `date`, `kind`, `n`, `metric`, `brain_score`, `control_score`, `comparator`, `experimental_unit`, `source_url`, and `caveat`. Where available they retain discordant counts, score differences, nominal probabilities, and local recalculations.

Read the unit and caveat before interpreting a contrast. Private-knowledge recall, retrieval, proof-error detection, safeguards, posture changes, and infrastructure checks measure different outcomes. Source-backed limitations include ambient memory in controls, unequal tools/context, batch-level replication, reused or development-tuned items, ceilings, missing token telemetry, and changed scoring stages.

W7's initial masked grades remain distinct from later adjudication after unmasking. M3's posture control already contained mathematical notes; it is not a brain-off baseline. Recounting a grade file verifies arithmetic, not its mathematical answer key, response independence, or contamination status. Original graders and solvers were not rerun for this paper.

`recomputed_grade_totals.json` records selected recounts. The package does not pretend to reconstruct every grade without its underlying records. Missing per-arm costs are not replaced with telemetry from another similarly named campaign.

At the refreshed snapshot, AB30 still has no committed run receipts, masked/adjudicated grade files or final result/token summaries. All 30 planned round-one pairs lack committed outcome evidence; the local completion count is unknown. The diet-arm code does not establish round-two enrollment or outcomes. Its protocol and analyzer provide methodology and implementation evidence only.

T11 is one four-arm operational context-use study, not four new independent benchmark cohorts. Its two judges assess the same ten outputs per arm, and its scores are net rubric points rather than correct-task counts. T12 measures retrieval; its agent-level pinned-hub comparison is explicitly not yet run. Consult the [revision-two index](update_20260923/README.md) for the arm table, selection limitations, source references and cost unknowns.

## 3. Interpret the research catalog

The eight retrieved inputs contain **1,391 physical records**, **1,168 distinct recorded identifiers**, and **223 repeated occurrences beyond one per identifier**. A separate inventory covers **87 top-level ProofNet directories**.

Repeated records can be revisions or repeated entries; they are not 223 additional problems. Seven mirrored queue files were excluded from a second count because they have the same Git blobs as their corresponding source files.

The projection retains inherited status/verification assertions and `review_status_this_paper=SOURCE_REPORTED_UNVERIFIED`. “Final observed row” means the final selected record under the projection policy, not a certified theorem or independently established current research state.

`source_publication_year_proxy` must not be used as the year a conjecture originated. `problem_origin_year_verified` remains blank where unverified. The separate reviewed chronology retains documented formulation dates and uncertainty. A universal oldest-to-newest ordering is not justified when origins are missing.

The 993 distinct nonempty inherited deduplication keys are not a reliable count of unique mathematical problems. Identifiers can overlap, and keys can combine distinct clauses. The inventory supports navigation and provenance, not a solved-problem count. Consult `README_RESEARCH_CATALOG.md` for input-level details.

## 4. Reproduce fresh parser and hook controls

Run:

```bash
python lean_controls/reproduce_controls.py
```

Consult `lean_controls/README.md` for exact fixtures. The result record preserves **11 receipt-parser controls** and a proof-hook routing check with **one positive and two negative inputs**. External knowledge access is disabled in the hook test.

These are local Python tests of supplied records and trigger behavior. A parser status named `FORMAL_TARGET_VERIFIED` means that the parser recognized its corresponding fixture; it does not mean that the reproduction command executed Lean. Translation fidelity remains a separate, unverified field.

Historical Lean companion logs are cited at pinned revisions. **No fresh Lean recompilation was performed for this review.** Checking algebraic companion lemmas does not automatically formalize the surrounding probability argument. Standard Mathlib axioms must not be described as an empty axiom set.

## 5. Reproduce the historical AB30 analyzer correction

Run:

```bash
python ab30_repair/reproduce_ab30_grouping.py
```

**Historical reproduction only:** this packet targets the earlier analyzer. Do not install its whole-file corrected copy over the current source; that would discard newer diet-arm and alternate-directory support. Use the rebased proposal in section 6 for integration.

The script creates three temporary synthetic pairs across two families, covering a win, a loss, and a tie. It first reproduces the original `TypeError` from applying set union to the list returned by `sorted`, then verifies the corrected family and combined grouping operation. Its expected final line is:

```text
PASS: synthetic regression only; no AB30 completion or native deployment claimed
```

The accounting check verifies that session-level `modelUsage` takes priority over a conflicting last-chain `usage` value and sums two fabricated model entries. Expected toy totals are input 7, cache read 30, cache write 10, output 12, and thinking 3. These are fixtures, not measured campaign costs; thinking must not be added again when it is already included in output.

The packet preserves original source, local correction, patch, manifest, and recorded stdout, and checks that the original bytes match the pinned Git blob. The synthetic pairs and scores **must not be counted as model trials, mathematical benchmark outcomes, or evidence that AB30 completed**. This repair addresses one grouping failure; it does not resolve all study-design or accounting limitations.

## 6. Reproduce the current-source audit and proposed repairs

From this supplement directory, run:

```bash
python3 update_20260923/analyzer/reproduce_update_audit.py
```

The [analyzer README](update_20260923/analyzer/README.md) gives exact source blobs, proposed changes and remaining limitations. The script verifies source and proposed hashes, reproduces the grouping crash and diet-flag interface mismatch, and exercises the repaired group operation plus all 12 arm/marker/inherited-value combinations. Additional controls reproduce grade, cohort, stream-audit, status and accounting limitations. The recorded validation uses fabricated records and mocked process boundaries, with zero model solvers and zero real hook processes. A disposable-tree patch check verifies byte-identical proposed outputs.

The proposal is [ab30_source_repairs.patch](update_20260923/analyzer/ab30_source_repairs.patch). It preserves current diet-arm and alternate-directory code. It does not add an unapproved scoring/retry/exclusion policy, demonstrate native activation or establish savings. Live application requires the normal native resource lease, assertion, current-file comparison and dispatcher equivalence/allowlist procedure. Native Claude acknowledgment and adoption remain unobserved in the inspected evidence. [Concrete handoff](../CLAUDE_HANDOFF.md).

## Disclosure and future versions

Held-out answer keys, private transcripts, and raw session histories are excluded. The usage histogram contains no session identifiers or private local project paths. Provenance locators do not certify the stored assertions.

Future reproductions should record their own dates, source revisions, model/tool policies, successful and failed runs, exclusions, grading stages, and full cost categories. Append new evidence as a new version rather than silently replacing the pinned historical record.
