# Mathematics of Pseudo-Cognitive Dynamics

Research paper dated 23 September 2026. The active model context is defined as the conscious layer; persistent external memory and control mechanisms form the subconscious layer. These are operational terms.

## Read and build

The delivered PDF is the formatted paper. `main.tex` is the Overleaf entry point. Upload this source package, select `main.tex`, and compile with pdfLaTeX. All required source sections, bibliography records, and the numeric bibliography style are included.

Locally, with TeX Live and latexmk installed:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

`pcd_numeric.bst` is a numeric, URL-preserving adaptation of `unsrtnat.bst`; its original LaTeX Project Public License notice is retained. It removes unnecessary author-year suffix generation for the large set of same-year archive citations.

## Contents

The paper covers the architecture and memory layers; salience and association mathematics; mistake memories, scars, instincts, and consolidation; Lean and statement fidelity; 45 recovered performance contrasts; construction and operating-cost accounting; a dated history of major mathematical research tracks; detailed proof mechanisms and unresolved bridges; a proposed experimental programme; and reproducibility.

The supplementary material preserves 1,391 source catalogue records representing 1,168 recorded IDs, 223 further versions, a 29-case reviewed chronology, 87 ProofNet directories, benchmark comparisons, aggregate usage data, detailed source reviews, and portable software checks. These counts do not mean 1,168 solved or mathematically independent conjectures. See `supplement/README.md` and `supplement/README_RESEARCH_CATALOG.md` for definitions and commands.

`CLAUDE_HANDOFF.md` identifies concrete findings for the connected worker. `supplement/ab30_repair/` is a tested proposal for one analyzer defect. It is not a live modification or evidence of completed AB30 trials. `supplement/lean_controls/` tests Python receipt parsing and routing; it does not run Lean.

## Evidence boundary

The paper uses frozen source revisions specified in its appendix. Historical model trials were inspected, with selected arithmetic independently recomputed. No new model-performance cohort or Lean kernel compilation was run for the paper. The all-time, construction-only, cross-provider token cost remains unidentified. Associated research manuscripts retain their individual proof, novelty, and attribution limits.

Private source links require appropriate repository access. Held-out answer keys and private model transcripts are excluded from this package.
