# Portable Lean-receipt and proof-routing controls

This package reproduces the paper's fresh local Python checks. It does not contain or execute a Lean compiler, prove any mathematical theorem, run an AI model, install a hook, or access deployed personal memory. The fixtures are synthetic parser messages and routing examples from the source's small self-test. Passing them demonstrates only the stated Python behaviors.

## Reproduce

With Python 3.9 or later, run from this directory:

```bash
python reproduce_controls.py
```

The script locates its two source modules relative to itself, so it can be invoked by its path from any working directory. It writes `results.json` beside the script. To place the JSON elsewhere, supply `--output PATH`. Existing files at that explicit output path are replaced.

The bundled observed result is also copied to `../lean_parser_controls_20260923.json` for the paper's appendix. The test checks the original existing `proof_sense._selftest()` and reports its three routing outcomes separately: one mathematical-argument trigger fires and two nonmathematical controls remain silent. Its knowledge-file path is temporarily redirected to a nonexistent file in an isolated temporary directory, so this does not measure successful memory retrieval.

Eleven direct controls exercise `proof_receipt.classify`: a synthetically valid standard-axiom report, missing named target, unreviewed source, wrong review hash, compilation failure, timeout, evidence drift, duplicate name output, non-theorem declaration, `sorryAx`, and a custom axiom. No Lean execution produced these fixture messages. All eleven must retain `translation_fidelity=UNVERIFIED`; the synthetic positive parser result does not certify any real proof.

## Source provenance

Repository: `<private-repo>`, snapshot `bcff9346b68959f4cf330fdf9ca0e64a21c77d3e`.

| Source | Exact Git blob | SHA-256 |
|---|---|---|
| `12_cognitive_architecture/dreaming/proof_receipt.py` | `da36e1504785fdc0672eca6eef04a31cd64e7399` | `f1b4d27b233c9588ba456458f17fceff619a87c3d99fadc7cb9db108b5dd3319` |
| `12_cognitive_architecture/dreaming/proof_sense.py` | `c778aa107b8e0e8a8da5ec915239e2f036d1f1ff` | `52c33eb6c36190c80e745f76fee3e6ff2b358f7085b79b9125e72f132dee0f99` |

The source copies are byte-identical to those objects. The portable test checks both Git blob identities before importing them. `source_manifest.json` records their byte lengths and digests. No production source changes are proposed in this package.

Public source locators, subject to repository access: [receipt parser](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/proof_receipt.py), [proof-routing hook](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/proof_sense.py).

## Interpretation

The observed report records 11/11 parser controls and 3/3 routing controls passing. These are not a mathematical accuracy benchmark, a formalization of the research papers, an end-to-end native integration test, or evidence that the brain improves an AI model's performance. Historical Lean build/axiom records discussed in the paper are separate evidence and were not rerun here.
