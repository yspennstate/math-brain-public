"""Portable pure-Python receipt and proof-routing controls.

Uses bundled source relative to this file and synthetic fixtures only. Deployed
knowledge retrieval is disabled. No native Lean compiler, LLM, network, hook
installation, or persistent runtime state is accessed. The JSON report is written
beside this script, or to an explicitly supplied --output path.
"""

import argparse
import contextlib
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PINS = {
    "proof_receipt.py": "da36e1504785fdc0672eca6eef04a31cd64e7399",
    "proof_sense.py": "c778aa107b8e0e8a8da5ec915239e2f036d1f1ff",
}


def load(name):
    path = HERE / (name + ".py")
    raw = path.read_bytes()
    blob = hashlib.sha1(b"blob " + str(len(raw)).encode("ascii") + b"\0" + raw).hexdigest()
    assert blob == PINS[path.name], (path.name, blob, "source drift")
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=HERE / "results.json")
    args = parser.parse_args()
    receipt, sense = load("proof_receipt"), load("proof_sense")

    with tempfile.TemporaryDirectory(prefix="lean-python-controls-") as tmp:
        # The knowledge file intentionally does not exist. These fixtures test
        # routing and rendering, without reading a user's deployed memory.
        sense.KNOWLEDGE = str(Path(tmp) / "no_deployed_knowledge.json")
        captured = io.StringIO()
        with contextlib.redirect_stdout(captured):
            selftest_exit = sense._selftest()

        proof = (
            "CLAIM: $\\P(X \\ge t) \\le e^{-t^2/2}$.\nARGUMENT:\n"
            "1. By Chebyshev's inequality, $\\P(|S_n - np| \\geq d np) \\le \\exp(-d^2 np/2)$.\n"
            "2. Let $m$ be the largest integer with $\\rho N^{-m} \\ge \\delta$; then $\\rho N^{-m+1} < \\delta$.\n"
            "3. Since the $X_i$ are independent, $\\limsup_n \\mu_n(F) \\le \\mu(F)$ for closed $F$ as $n \\to \\infty$.\n"
            "4. Hence $\\sup_x f(x) \\le \\int f \\, d\\mu$ and the claim follows."
        )
        routing_fixtures = [
            ("positive_math_argument", proof, True),
            ("negative_administrative_request",
             "please only use the desktop app, not the api, and make exactly 3 charts of the book's pnl; do not deploy anything.", False),
            ("negative_conversational_question",
             "how long will this take? and why did the brain do worse in round 1?", False),
        ]
        routing = []
        for name, prompt, expected in routing_fixtures:
            rendered = sense.render(prompt)
            fired = rendered.startswith("[proof-sense]")
            routing.append({"name": name, "expected_fired": expected,
                            "observed_fired": fired, "passed": fired == expected})
        assert all(item["passed"] for item in routing)

    target = "Audit.trueProof"
    source_hash = hashlib.sha256(b"synthetic control fixture").hexdigest()
    name_json = json.dumps(receipt.name_tree(target))
    axiom_json = json.dumps([receipt.name_tree(a) for a in sorted(receipt.STANDARD_AXIOMS)])
    good = (f"TARGET_NAME {target}: {name_json}\n"
            f"TARGET_KIND {target}: theorem=true\n"
            f"TARGET_AXIOMS {target}: {axiom_json}")
    cases = [
        ("valid_standard_axioms", {}, good, "FORMAL_TARGET_VERIFIED"),
        ("no_named_target", {"target": None}, good, "COMPILED_NO_NAMED_TARGET"),
        ("unreviewed", {"reviewed_sha256": None}, good, "COMPILED_SOURCE_UNREVIEWED"),
        ("review_mismatch", {"reviewed_sha256": "0" * 64}, good, "SOURCE_REVIEW_MISMATCH"),
        ("failed_compile", {"returncode": 1}, good, "COMPILE_FAILED"),
        ("timeout", {"timed_out": True}, good, "RUNTIME_UNVERIFIED"),
        ("evidence_drift", {"evidence_integrity": False}, good, "EVIDENCE_DRIFT_OR_MISSING"),
        ("duplicate_name", {}, good + "\n" + good.splitlines()[0], "TARGET_IDENTITY_MISSING_OR_MISMATCH"),
        ("not_theorem", {}, good.replace("theorem=true", "theorem=false"), "TARGET_NOT_THEOREM"),
        ("sorry", {}, good.replace(axiom_json, json.dumps([receipt.name_tree("sorryAx")])), "ADMITTED_TARGET"),
        ("custom_axiom", {}, good.replace(axiom_json, json.dumps([receipt.name_tree("My.assumption")])), "UNAPPROVED_AXIOMS"),
    ]
    results = []
    for name, change, output, expected in cases:
        kwargs = dict(returncode=0, source_sha256=source_hash,
                      reviewed_sha256=source_hash, target=target)
        kwargs.update(change)
        result = receipt.classify(output=output, **kwargs)
        results.append({"name": name, "status": result["status"], "expected": expected,
                        "passed": result["status"] == expected,
                        "translation_fidelity": result["translation_fidelity"]})
    assert all(item["passed"] for item in results)
    assert all(item["translation_fidelity"] == "UNVERIFIED" for item in results)
    report = {
        "date_utc": datetime.now(timezone.utc).date().isoformat(),
        "scope": "fresh local pure-Python parser and trigger controls only; no Lean compiler execution, no model benchmark",
        "source_refs": {"broad_commit": "bcff9346b68959f4cf330fdf9ca0e64a21c77d3e",
                        "proof_receipt_git_blob": PINS["proof_receipt.py"],
                        "proof_sense_git_blob": PINS["proof_sense.py"]},
        "proof_sense_selftest": {"exit": selftest_exit,
                                 "output": captured.getvalue().strip(),
                                 "external_knowledge_disabled": True},
        "routing_controls": routing,
        "routing_passed": sum(item["passed"] for item in routing),
        "routing_total": len(routing),
        "receipt_controls": results,
        "passed": sum(item["passed"] for item in results),
        "total": len(results),
        "kernel_checked": False,
        "empirical_brain_advantage_measured": False,
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print("SOURCE_IDENTITY_PASS: both bundled Python files match pinned Git blobs")
    print("RECEIPT_CONTROLS_PASS: 11/11; translation fidelity remains UNVERIFIED")
    print("ROUTING_CONTROLS_PASS: 3/3 (one positive, two negatives); deployed knowledge disabled")
    print("PASS: no native Lean run or model-performance comparison")


if __name__ == "__main__":
    main()
