# Supplemental benchmark audit: round-5 W7 and M3 posture trials

All sources fetched from `<private-repo>` at commit `bcff9346b68959f4cf330fdf9ca0e64a21c77d3e`. The JSON row totals below were independently recomputed locally. No solver or original grader was rerun.

## W7 mathematical knowledge / store-fidelity bank

Source prefix: `12_cognitive_architecture/brain_improvement/campaign_2026-09-22_opus55_round5/w7_math_test/`.

Eighty questions: 50 on specific store results (41 house/campaign results plus nine external 2025–2026 results); ten on what stored cards say about the current quadratic-form conjecture; twenty standard graduate-level controls. The ten conjecture questions are retrieval/status questions, not ten attempts at solving the conjecture. Questions were shuffled, key terms screened against ambient files, and one item (`MQ053`) dropped as contaminated. The control retained ambient injected instruction/memory files and was permitted only one bank Read and one answer Write. This is a comparison of full information-access policies, not an equal-tool or equal-compute content ablation. The README explicitly notes moving ambient preload files and possible historical-prompt injection on tool calls.

| Subset | n | Raw blind full-correct brain/control | Adjudicated full-correct brain/control | Adjudicated paired brain-only/control-only |
|---|---:|---:|---:|---:|
| Stored mathematical results | 49 | 47 / 7 | 49 / 8 | 41 / 0 |
| RMT store-card questions | 10 | 10 / 4 | 10 / 4 | 6 / 0 |
| Standard controls | 20 | 19 / 19 | 20 / 20 | 0 / 0 |
| All retained items | 79 | 76 / 30 | 79 / 32 | 47 / 0 |

Raw total rubric points: 77.0/79 brain versus 35.5/79 control. Adjudicated: 79.0 versus 37.0. Rubric points differ from full-correct counts because half credit is possible.

**Adjudication occurred after unmasking.** `grade/ADJUDICATION.json` explicitly identifies the integrator and says “after unmasking; the grader's own key-dispute flags are the starting point.” Six masked rows were adjudicated, five resulting in score increases (three brain responses and two control responses); one brain score remained full credit while its key was corrected. Thus the perfect 79/79 is a post-unmasking adjudicated score, not purely blind initial grading. The raw and adjudicated outcomes should be preserved together.

Recorded reasons include a stale gossip bound after a false component-sum identity; an invalid inference from equality of free/wired minimal spanning forests to connectivity; a historical priority error about last-passage fluctuations; and a false claim of projective rigidity of the 24-cell. These are credible reasons to investigate and correct keys, but this audit has not independently verified every cited mathematical correction. They illustrate that reproducing a memory-store statement is not the same as answering correctly about mathematics. The study sometimes rewarded rejecting the retrieved card.

Important source URLs:

- [Bank design](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/brain_improvement/campaign_2026-09-22_opus55_round5/w7_math_test/bank/README.md)
- [Raw grades](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/brain_improvement/campaign_2026-09-22_opus55_round5/w7_math_test/grade/RESULT.json)
- [Adjudicated grades](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/brain_improvement/campaign_2026-09-22_opus55_round5/w7_math_test/grade/RESULT_ADJUDICATED.json)
- [Adjudication record](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/brain_improvement/campaign_2026-09-22_opus55_round5/w7_math_test/grade/ADJUDICATION.json)
- [Control prompt](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/brain_improvement/campaign_2026-09-22_opus55_round5/w7_math_test/arm_control/PROMPT.md)

## M3 proof-sense posture variants

Source prefix: `12_cognitive_architecture/brain_improvement/campaign_2026-09-12_ultracode_mathbrain/lanes/m3_proofsense/`.

The measured set was deliberately chosen: all 48 flawed items from bank-100, a seeded 20 of its 52 clean items, and all 35 harder-bank items. Total 103 = 67 flawed + 36 clean. Posture appeared on 91 items. Sonnet subagents each handled a shard; original shard size was 15. Conditions differed only in the posture string in captured reference material: mathematical notes, class checks, items, instructions, order, and shard size were held constant. Thus “control” here is a baseline posture within a notes-present condition, not brain-off. It is not the same control meaning as in W7 or recall studies.

| Condition | Correct / 103 | Flawed correct / 67 | Clean correct / 36 | False positives | Paired helped/harmed vs same-run control |
|---|---:|---:|---:|---:|---:|
| Baseline posture | 94 | 58 | 36 | 0 | — |
| v1 | 94 | 59 | 35 | 1 | 2 / 2 |
| v3 | 94 | 61 | 33 | 3 | 5 / 5 |

Both variant comparisons have reported exact paired p=1.000. The variants traded more flawed-proof detection for more false alarms, with unchanged total correctness. v3 also had one uncertain response. The score-based landing rule required helped ≥ harmed+2 and no new clean false positives; neither variant satisfies it.

`GRADE_v3_complete.txt` is an interim file with only 30/103 v1 responses; `GRADE_v1_v3_complete.txt` supersedes it with all 103. They must not be counted as two independent experiments. Comparisons to a previous no-notes arm are explicitly **cross-run** and do not supply the same-run posture contrast.

A separate shard-size comparison gives baseline posture with shard size 5: 97/103 correct, 61/67 flawed, 36/36 clean, zero false positives; shard size 15: 94/103, 58/67, 36/36. Discordance is 3/0, exact p=.25. This is a limited observation of batching effects, not statistically established universal superiority of smaller shards. The original session also required a follow-up after a solver returned only ten answers to a fifteen-item shard.

Sources:

- [Design/status](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/brain_improvement/campaign_2026-09-12_ultracode_mathbrain/lanes/m3_proofsense/STATUS.md)
- [Complete variants grade](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/brain_improvement/campaign_2026-09-12_ultracode_mathbrain/lanes/m3_proofsense/GRADE_v1_v3_complete.txt)
- [Shard-size grade](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/brain_improvement/campaign_2026-09-12_ultracode_mathbrain/lanes/m3_proofsense/GRADE_shardsize_5_vs_15.txt)
- [Solver prompt](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/brain_improvement/campaign_2026-09-12_ultracode_mathbrain/lanes/m3_proofsense/SOLVER_PROMPT.md)

No per-arm usage telemetry for these W7 or M3 trials was located in the inspected file set. Do not borrow token totals from another similarly named campaign.
