# Construction-token evidence audit for Mathematics of Pseudo-Cognitive Dynamics

## Decision for the paper

**A precise all-time Math Brain construction cost is not established by the available ledger.** The repository contains an auditable, partial machine-wide Claude Code usage record spanning 2026-08-09 through 2026-09-09. It combines development, research, evaluation, and other sessions, and most usage is assigned to a generic working directory. Report its exact token categories and scope; do not describe the grand total as tokens exclusively spent constructing Math Brain.

A suitable paper sentence:

> The available archival usage ledger records 375,282,198 output tokens and 123,820,924,963 input-token events, including cache reads, across a 32-day interval. These measurements cover Claude Code transcripts on one machine and combine construction, evaluation, and use; the ledger does not identify the all-time or Math Brain-specific construction cost.

Source snapshot: `<private-repo>` commit `bcff9346b68959f4cf330fdf9ca0e64a21c77d3e`. Audit date: 2026-09-23. Values below were computed directly from TSV contents, not inferred from commits, manuscript lengths, stored memory sizes, or model estimates.

## Exact total usage recorded

| Field in stored TSV | Exact total | Meaning |
|---|---:|---|
| `input` | 9,932,399 | Reported uncached input tokens |
| `cache_read` | 122,293,331,806 | Reported input tokens read from provider prompt cache |
| `cache_create` | 1,517,660,758 | Reported input tokens used to create provider prompt cache entries |
| `output` | 375,282,198 | Reported generated output tokens |
| Three input categories combined | 123,820,924,963 | Input-token events, including repeated cached prefixes |
| Four usage categories combined | 124,196,207,161 | Input plus output token events; not unique content or generated text |
| Input + cache creation + output (cache reads excluded) | 1,902,875,355 | A mathematically computable subtotal, not a unique-content measure or a build-cost measure |

Sources: [daily.tsv](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/usage_ledger/daily.tsv), [sessions.tsv](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/usage_ledger/sessions.tsv), [ledger builder](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/usage_ledger/build_usage_ledger.py).

Provider definition: Anthropic's official [prompt caching documentation](https://platform.claude.com/docs/en/build-with-claude/prompt-caching#tracking-cache-performance) defines total input as the sum of uncached input, cache creation, and cache read fields. These are distinct usage categories. Cached prefixes can recur across requests; summing token events does not measure unique knowledge, model training, stored corpus size, or mathematical information content. Cache categories have different prices, so unweighted token sums are not invoices.

Cache reads are 98.46784745% of the four-field total; output is 0.30216881%. These are **token-event shares**, not cost shares. The README's statement about output representing roughly a fifth of API-equivalent spend is not verified by these unweighted shares. No provider invoice, historical model-specific price table, cache-duration breakdown, subscription allocation, discounts, or currency ledger was found in this usage-ledger folder.

## Coverage and consistency checks

- Stored dates: 32 UTC calendar days, 2026-08-09 to 2026-09-09 inclusive.
- Earliest session timestamp: 2026-08-09T13:48:35.559000+00:00.
- Latest session timestamp: 2026-09-09T09:47:13.372000+00:00.
- 244,194 assistant usage messages are represented.
- `sessions.tsv`: 11,774 rows; all 11,774 session identifiers are distinct in this file.
- The README reports **11,999 transcripts scanned** on first build. That is not the same quantity as session rows with accepted usage. The builder skips sessions whose accepted-message count is zero.
- Of the 11,774 session rows, 2,124 have dominant model label `<synthetic>`, representing 2,126 messages and exactly zero in all four token fields. Thus neither 11,999 nor 11,774 should be advertised as the number of paid model inference sessions.
- `half_hours.tsv`: 18,502 (project, session, half-hour) rows, of which 16,008 have strictly positive output.
- The four category totals computed independently from `daily.tsv` and `sessions.tsv` agree exactly. Output also agrees exactly with the sum of `half_hours.tsv`.
- The sum of daily active-session counts is 11,944, which is not a distinct-session count because a session can be active on multiple dates.
- Peak daily output: 29,147,485 tokens on 2026-09-02.
- The ledger predates the paper's 2026-09-23 snapshot by roughly two weeks. It is not a current all-provider total.

Sources: [README](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/usage_ledger/README.md), [sessions.tsv](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/usage_ledger/sessions.tsv), [daily.tsv](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/usage_ledger/daily.tsv), [half_hours.tsv](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/usage_ledger/half_hours.tsv).

## Working-directory attribution

These groups come from the `project` column, which the builder obtains from the transcript's parent directory. This is CWD-based grouping, not verified task accounting. In particular, a session launched in the home directory can still create or use Math Brain. Sessions launched under an evaluation directory need not represent independent successfully completed tests. Do not add these figures to benchmark operational costs without deduplicating the underlying messages: the same test calls may already be in this ledger.

| Working-directory group | Session rows | Messages | Uncached input | Cache read | Cache creation | Output |
|---|---:|---:|---:|---:|---:|---:|
| Generic user-home working directory | 589 | 231,098 | 9,764,864 | 121,134,920,654 | 1,418,475,661 | 300,134,682 |
| Math/probability analytical 10x v1 | 343 | 360 | 3,464 | 10,988,042 | 5,435,771 | 1,933,618 |
| Math/probability bank10k | 3,997 | 3,999 | 24,440 | 60,380,480 | 41,459,624 | 20,755,930 |
| Brain improvement 2026-08-22 COORD realtest | 1,696 | 1,700 | 16,710 | 32,817,032 | 24,157,960 | 14,960,584 |
| Brain improvement 2026-08-22 B12 bank research | 1,521 | 1,521 | 14,790 | 32,070,779 | 6,947,225 | 17,166,731 |
| Brain improvement 2026-09-05 harder test | 1,379 | 1,382 | 2,064 | 8,063,339 | 2,830,539 | 451,337 |
| Brain improvement 2026-09-06 probability literature bank | 1,866 | 1,868 | 10,918 | 10,442,757 | 4,585,872 | 15,968,146 |
| Brain improvement 2026-09-06 multidomain bank | 6 | 6 | 60 | 34,054 | 12,212 | 19,693 |
| Probability bank hook smoke | 1 | 1 | 2 | 0 | 55,840 | 22,645 |
| Probability bank hook serve CWD | 349 | 349 | 630 | 884,465 | 7,189,480 | 1,950,587 |
| Probability bank hook | 1 | 1 | 2 | 0 | 4,882 | 4 |

Aggregated subsets:

| CWD grouping | Session rows | Messages | Uncached input | Cache read | Cache creation | Output | Sum of four fields |
|---|---:|---:|---:|---:|---:|---:|---:|
| Explicit `06-math-research` evaluation CWDs | 4,340 | 4,359 | 27,904 | 71,368,522 | 46,895,395 | 22,689,548 | 140,981,369 |
| Explicit `12-cognitive-architecture` brain-improvement CWDs | 6,819 | 6,828 | 45,176 | 84,312,426 | 45,784,010 | 50,539,727 | 180,681,339 |
| Those two subsets combined | 11,159 | 11,187 | 73,080 | 155,680,948 | 92,679,405 | 73,229,275 | 321,662,708 |

The generic user-home CWD alone accounts for 79.97573122% of output and 99.05276017% of cache reads. Therefore the explicit math/architecture CWD subtotal cannot supply a reliable Math Brain construction total. It is an identifiable directory-associated subtotal, not a lower bound on construction cost: some of its calls are operating/evaluating the system rather than constructing it.

One further session under a dreaming CWD records 1,884 messages, 94,237 uncached input, 1,002,367,710 cache-read, 6,308,732 cache-creation, and 1,900,062 output tokens. Its directory identifies dreaming activity, but this does not prove that every token in that session created the mathematical subsystem.

## Ledger-generation algorithm and limits

The [builder](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/usage_ledger/build_usage_ledger.py) performs the following procedure:

1. Glob the local path `~/.claude/projects/*/*.jsonl` (one project level only).
2. Scan only lines containing a usage object; parse JSON and accept assistant records.
3. Require a message identifier and nonempty usage object.
4. Deduplicate **globally** by message identifier using a `seen` set.
5. Parse a timestamp; add integer values from `output_tokens`, `input_tokens`, `cache_read_input_tokens`, and `cache_creation_input_tokens`, with missing values coerced to zero.
6. Aggregate by transcript, day, and fixed 30-minute UTC bucket.
7. Write only usage metadata, timestamps, and model labels, with no prompt or response contents.

This is a useful privacy-preserving accounting layer. Its limits matter for the paper:

- First-seen duplicate wins; there is no merge of later usage updates or comparison of duplicate values. Without original message records, final usage completeness cannot be independently audited.
- `seen.add(mid)` occurs **before** timestamp validation. If the first encountered record lacks a valid timestamp, later duplicates are skipped even if their timestamp is valid.
- File traversal uses an unsorted glob. If inconsistent duplicate records occur, order can affect which record survives.
- Missing files, rotated transcripts, malformed JSON, missing IDs, and absent usage fields are omitted. Other machines, providers, ChatGPT/other agents, and dates outside the archived interval are not covered by this ledger.
- The `model` field in `sessions.tsv` is the **most frequent message model** in a session. All session token totals are attached to that one label. Thus summing tokens by the stored session model label is not a valid exact per-model billing reconstruction when sessions contain multiple models.
- Cache creation is not split into cache-duration categories, so a exact historical billing reconstruction would remain impossible even with correct session model attribution.
- The aggregates are mutually consistent, but aggregate consistency cannot establish transcript completeness or provider billing correctness.
- Rebuilds overwrite all three TSV files rather than merging a previous archive. After source transcript rotation, rerunning this script could discard older ledger history unless previous versions are retained separately.
- Code was inspected; it was not rerun on the user's private original transcript directory, which is unavailable here.

Relevant source locations: glob at line 42; deduplication and timestamp handling at lines 71–77; token extraction at lines 78–81; dominant-model assignment at line 108.

## README discrepancy: output-cap simulation

The [README](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/usage_ledger/README.md) says that a cap of 30,000 output tokens per session per 30 minutes would have throttled 9% of active half-hours. Applying that threshold directly to the stored [half_hours.tsv](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/usage_ledger/half_hours.tsv) produces:

| Denominator | Number of buckets | Buckets exceeding 30,000 output | Proportion |
|---|---:|---:|---:|
| Every recorded session/half-hour row | 18,502 | 4,230 | 22.86239325% |
| Positive-output session/half-hour rows | 16,008 | 4,230 | 26.42428786% |

Maximum stored bucket output is 155,129. No bucket equals exactly 30,000, so strict versus non-strict threshold is irrelevant here. The 9% statement is not reproducible from these denominators. It may have used an unstated subset or prior data, but the paper should omit it or explicitly label the mismatch. This is an accounting consistency check, not a test of mathematical problem-solving ability.

## What the paper can and cannot conclude

**Supported:** This project maintained substantial, structured transcript-derived usage data; the measured sample records 375.282 million output tokens over 32 days; the context-token volume is dominated by cache reads; explicit math and brain-evaluation directory groups can be quantified; all three TSV aggregates agree on total output.

**Not supported:** “Math Brain took 124.196 billion tokens to build”; “375.282 million output tokens were all spent on Math Brain”; “this is the complete all-time cross-provider cost”; any dollar bill calculated by applying one current price to all token events; “Math Brain saves x% of tokens” based only on this construction ledger; inferring performance from tokens, commits, memories, or sessions.

For operating efficiency, use paired benchmark trials and report the full vector of solver input, solver output, cache-read, cache-create, retrieval, verification/auditing, and memory-update costs under matched conditions. Report construction and continuing maintenance separately. If provider API costs are quoted, label them API-equivalent estimates unless reconciled to provider bills.

A proposed future accounting framework (methodological recommendation, not an already measured result) is:

- Tag each request with immutable request ID, provider, exact model, task/campaign, treatment arm, brain snapshot, usage categories, cache TTL, and activity type (construction / maintenance / solving / retrieval / verification).
- Assign shared construction costs explicitly rather than using CWD or commit counts as a proxy.
- For a fixed evaluation horizon N, compare total brain cost B + sum(operation costs) with baseline sum(operation costs), alongside independently graded correctness. A break-even expression N = B/(mean baseline operating cost − mean brain operating cost) is defined only if the operating saving is positive, all costs use a consistent unit, and the compared outcomes have comparable quality.
- There is no empirical break-even N available from the construction ledger alone.

## Raw daily ledger (exact transcribed source)

```tsv
day_utc	sessions	msgs	input	cache_read	cache_create	output	max_session_output
2026-08-09	3	1541	3138	752158186	42446212	2263263	1499720
2026-08-10	7	7750	16573	4126651126	74496704	9611046	4188303
2026-08-11	16	10739	31499	5669299840	87072495	12443369	3262042
2026-08-12	14	11638	24814	6369745192	60514089	14847199	3036456
2026-08-13	20	13618	39235	7080643323	74284170	16726624	3063074
2026-08-14	14	12038	22451	6338323826	39690102	13788766	3575049
2026-08-15	17	8239	16244	4349543489	34118305	8623602	2344100
2026-08-16	144	2718	6466	1233901083	13284320	3479404	1610846
2026-08-17	1084	6783	26653	2982275148	52873218	15240640	2505757
2026-08-18	469	5746	14940	2409356118	47049790	10664604	1396860
2026-08-19	17	5101	10031	2581877471	40136608	6033908	1473638
2026-08-20	20	9134	46990	4606346376	44780012	13029982	3504536
2026-08-21	13	8565	93435	4657806315	35059731	9973823	3112232
2026-08-22	492	12352	28372	6429642312	63483485	19197138	2492872
2026-08-23	772	12677	200502	6387378245	82931432	20585227	2806036
2026-08-24	23	12393	312934	6766222155	40626096	14858498	3659424
2026-08-25	13	9903	570109	5075511638	39611598	12666233	2981020
2026-08-26	13	9226	143418	5209174899	60921291	12148270	2512104
2026-08-27	21	9480	437750	4964550007	75730778	11731304	2055310
2026-08-28	167	7340	15997	4020653116	43213899	11379153	2140463
2026-08-29	588	11488	561598	5681543202	58715396	23525270	3031469
2026-08-30	17	4415	1062522	2120878764	23189973	8162747	1979903
2026-08-31	44	2443	5147	1305604802	13597669	3603786	1186932
2026-09-01	2843	10883	1280805	3870054583	81348267	21216220	2346844
2026-09-02	1402	9424	3458259	4478782530	99971868	29147485	2519660
2026-09-03	15	4521	1165589	2475878821	32907032	6834662	1088083
2026-09-04	12	3757	7501	1956722915	10595298	3428091	1535907
2026-09-05	665	4030	170363	1817511093	21918856	6246282	1287122
2026-09-06	2626	4713	61966	983706781	27624302	18969839	432536
2026-09-07	364	6024	52463	2769385941	61788254	7951688	1098456
2026-09-08	18	4685	23727	2469722645	23904136	5763116	1636543
2026-09-09	11	830	20908	352479864	9775372	1140959	214643
```

## Reproducibility snippet

With the three TSVs exported without modification, this standard-library code reproduces the principal aggregate checks:

```python
import csv
from pathlib import Path

root = Path("12_cognitive_architecture/usage_ledger")
def rows(name):
    with (root / name).open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter="\t"))

daily = rows("daily.tsv")
sessions = rows("sessions.tsv")
half_hours = rows("half_hours.tsv")
fields = ("input", "cache_read", "cache_create", "output")
dt = {k: sum(int(r[k]) for r in daily) for k in fields}
st = {k: sum(int(r[k]) for r in sessions) for k in fields}
assert dt == st
assert st["output"] == sum(int(r["output"]) for r in half_hours)
positive = [r for r in half_hours if int(r["output"]) > 0]
above = sum(int(r["output"]) > 30000 for r in half_hours)
print(dt)
print("four-field sum", sum(dt.values()))
print("sessions", len(sessions), "messages", sum(int(r["msgs"]) for r in sessions))
print("half-hours", len(half_hours), "positive", len(positive), "above 30k", above)
```
