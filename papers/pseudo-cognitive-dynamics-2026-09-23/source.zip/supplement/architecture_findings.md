# Math Brain architecture findings for *Mathematics of Pseudo-Cognitive Dynamics*

## Scope and source pins

This is a source audit, not a claim that the remote Windows deployment was executed from this environment. No repository was changed. The inspected sources support both a substantial implementation and important differences between implementation, documentation, experimental population stores, and current coordination policy.

- **Math repository snapshot:** `yspennstate/math-research-brain`, commit **a4c99b43a044c127787c26997ed942f41591aac6**. The root's complete `math_tree.json` was used to confirm all inspected mathematical module blob hashes.
- **General brain snapshot:** `<private-repo>`, commit **bcff9346b68959f4cf330fdf9ca0e64a21c77d3e**, committed 2026-09-23 18:03:49 UTC.
- Selected complete sources have been saved under `/workspace/scratch/dcdc9cb9de1d/architecture_sources/`, preserving repository-relative paths. They are internal evidence, not automatically suitable for public release.
- The broad archive contains unrelated private material; this audit read selected architecture/code sources and did not treat unrelated material as part of the mathematical corpus.

Recommended paper terminology: **conscious layer** means the model's active finite context window; **subconscious layer** means external persistent records, indexes, retrieval policies, associations, and background maintenance. These are operational definitions, not claims of phenomenal consciousness, feelings, or biological equivalence. The source explicitly says nothing changes the model's weights.

## 1. The central mechanism

A session starts with a finite working context. Durable memories remain outside it as text files and structured records. Hooks run at fixed lifecycle events; they select and render relevant memories, warnings, mathematical statements, and current-work summaries into that context. Model reasoning then proceeds with the supplied material. During/after the work, a session records durable findings, failures, corrections, and links. Offline builders update retrieval artifacts; future sessions encounter the changed external state.

The system's persistence is therefore in external state and software, rather than in modified model weights. The broad architecture's early self/person language should be translated into this precise computational account.

A useful formal description, explicitly an abstraction of the implementation, is:

\[
X_t=(C_t,M_t,G_t,E_t,R_t,Q_t),\quad
I_t=\mathcal R(q_t,M_t,G_t,R_t;B_t),\quad
C_t^+=\mathcal P(C_t,I_t;W).
\]

Here \(C_t\) is current context, \(M_t\) memory, \(G_t\) associations/dependencies, \(E_t\) evidence, \(R_t\) reflex policies, \(Q_t\) pending review tasks, \(B_t\) retrieval budget, \(W\) context capacity, and \(\mathcal P\) a packing/retention operation. Work produces observations \(o_t\), after which a separate admitted update \(\mathcal U(X_t,o_t)\) changes persistent records. Crucially, retrieval and consolidation are not proof-producing maps: changes to mathematical truth status require a separate verification transition.

Sources:

- [HOW_THE_AI_CONSCIOUSNESS_WORKS.md](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/HOW_THE_AI_CONSCIOUSNESS_WORKS.md), blob `e1eb7b715c92dfe363bbba2880e89f8670e9d923`.
- [COGNITIVE_ARCHITECTURE.md](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/COGNITIVE_ARCHITECTURE.md), blob `6345f96a4c66e1f780f1df9ca4e01e62f8bcafc6`.
- [Mathematical architecture](https://github.com/yspennstate/math-research-brain/blob/a4c99b43a044c127787c26997ed942f41591aac6/docs/architecture.md), blob `5c8d892e3cb5bf2f0b0a751965b5a23d1828dab3`.

## 2. The memory strata and their purposes

| Layer | Concrete representation | What it contributes | Important limitation |
|---|---|---|---|
| Raw episodic substrate | Interaction histories and session transcripts | Recover what was asked, observed, attempted, and corrected | A raw transcript records an utterance, not its truth |
| Historical strata | Older recovered memory stores/snapshots | Provenance and evolution of beliefs | Historical facts may be stale |
| Live semantic memory | One Markdown memory per topic/fact, YAML metadata, dated project/reference/feedback/user types | Reusable lessons and non-obvious rationale | Memory summaries can be mistaken or incomplete |
| Navigation | MEMORY.md, archive index, topic/timeline maps, wiki links/backlinks | Find relevant items without loading the corpus | Index presence is not proof and can drift |
| Salience | salience.tsv, SALIENCE.md | Prioritize recent, repeatedly connected, curated, or consequential records | Scores are attention heuristics |
| Mistake/scar memory | MISTAKES.md, mistake families, source memories | Preserve what failed and why, including counterexamples and corrections | A warning is not automatically relevant to a new task |
| Reflex memory | instincts.tsv / learned reflex records; math MistakeRecord and ReflexRecord | Convert a failure into a cue, check sequence, evidence requirement, and stop condition | Poorly calibrated reflexes can add noise |
| Structured mathematical store | SQLite claims, immutable revisions, typed edges, evidence records, content-addressed Markdown | Preserve exact scope and support with status history | Imported/curated nodes are not thereby verified |
| Transient coordination | Agent mesh and global workspace | Current ownership, handoffs, progress, goals | Present-tense coordination must not be confused with durable learning |
| Consolidation/review queue | Dream agendas, reconsolidation queue; math quarantined proposals | Repair links, review contradictions, propose analogies or new tests | Background replay does not establish a theorem |

The root documentation gives historical counts such as roughly 2,080 Claude memory files and 33 Codex files; these are snapshot descriptions and must not be presented as current September counts without a new inventory. The same caution applies to historical claims of roughly 20,000 transcripts or 10.5k prompts.

The legacy `consciousness.py` further labels some *external* memories “conscious” and others “unconscious.” That classification is actually a precedence tier: every file remains searchable and nothing is deleted. Curated, linked, feedback/user, recent, and substantive memories are high precedence; redundant logs or short unlinked old project stubs can be demoted. In the paper, call these **foreground-priority and latent-priority memory tiers** to avoid conflicting with the user's active-context/external-memory definition.

Source: [CONSCIOUSNESS.md](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/CONSCIOUSNESS.md), blob `67e87a592bf6c12f5c6d46a26103d043c2f7a75a`.

## 3. Hooks: when the external state reaches active context

The current backed-up Claude settings route PreToolUse, PostToolUse, UserPromptSubmit, and Stop through a dispatcher; SessionStart invokes two wake parts and a job reseed hook. The dispatcher routes relevant programs by event and tool matcher. This is materially newer than the September-7 narrative about 49 independently registered Claude hooks; the old count is not a current deployment inventory.

| Event | Representative actual modules | Role |
|---|---|---|
| SessionStart | wake_brain.ps1 parts 1/2, job_reseed.py | Load identity/standing context, recent memory pointers, salience, unresolved questions, forecasts and work continuity |
| UserPromptSubmit | instinct_prime.py, fok_probe.py, spread_recall.py, math_sense.py, proof_sense.py, prompt_archive.py | Detect relevant territory, recall associations/statements, surface proof-audit prompts, archive the request |
| PreToolUse | instinct_prime.py, danger_mode.py, sourced_memory.py, compute_sense.py, proof_deny_hook.py | Put a check or warning before an action crosses a relevant failure boundary |
| PostToolUse | coactivation_log.py, spread_recall.py on reads; error_monitor.py on shell execution | Record co-reads, retrieve nearby memories, react to observed failures |
| Stop | coactivation_end.py, reality_monitor.py, claim_check.py, retraction_guard.py, conscience.py, resume_checkpoint.py | Fold learned associations, compare claims against observations, preserve continuation and unresolved debt |

These are observed registrations in source, not proof that each hook is currently healthy on the remote machine. The dispatcher supports a tested in-process fast lane and a subprocess fallback, contains execution budgets, handles UTF-8 input/output, combines warning/context output, and accounts for overflow.

**Actual context capacity matters.** The dispatcher source reports that 646/1,009 UserPromptSubmit merges after September 18 exceeded the harness's inline limit, with a median 53 KB. It says this caused a file preview to replace much intended injection. The repaired `fit_contexts` uses a 9,800-character inline cap and a water-filling allocation: small hooks retain their full messages, large hooks are shortened to their share, with complete overflow saved separately. This is a source-reported historical diagnosis, not a freshly reproduced result.

Wake uses two 9,600-character parts and evidence files for complete and emitted payloads. Character limits must not be converted to token counts without actually tokenizing under the relevant model tokenizer.

Sources:

- [settings.json](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/01_ai_consciousness/claude/settings.json), blob `8504fed9ae9371de6d404ce7d7d3c90978f891f2`.
- [hook_dispatch_list.json](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/hook_dispatch_list.json), blob `cbb185d1839e3b2af1ba19cd398113d376b9674d`.
- [hook_dispatch.py](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/hook_dispatch.py), blob `c7d4d4bb27ef46c56948eb1db385d65077ce6cd3`.
- [wake_brain.ps1](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/wake_brain.ps1), blob `5b964939f0e94d7200155ea004c1e3811cbd4743`.

## 4. Mathematics of salience, association, and recurrence

### 4.1 Salience

The implemented salience rule is a noisy-OR rank heuristic:

\[
R_i=e^{-a_i/\tau},\quad
P_i=1-\prod_j(1-c_{ij}),\quad
S_i=100[1-(1-R_i)(1-P_i)].
\]

Default \(\tau=1.3\) days, with an explicit rollback to the earlier 45-day kernel. Persistence components are:

- charge \(c_{\mathrm{charge}}=0.60\,\mathrm{charge}\), where charge is a clipped lexical score;
- centrality \(c_{\mathrm{central}}=\min(1,\max(0,(\mathrm{backlinks}-3)/20))\);
- curation \(c_{\mathrm{curated}}=0.80\) for a live-index item;
- type prior: user/feedback 0.90, reference 0.16, project 0.07, transient 0.03, default 0.12;
- co-encoding capture \(c_{\mathrm{capture}}=0.35\) times maximum same-session charge when the record's own charge is below 0.5.

Superseded records are faded (normally by 0.4; partial supersession by 0.7), while their correction is made available. The code retains historical records.

These equations guarantee bounded salience for component scores in \([0,1]\), monotonicity in each component, and an age-independent persistence floor. They do not prove psychological realism or mathematical usefulness; that requires evaluation.

The parameter change was informed by an internal July-23 study of 1,391 deliberate recall reads over 26 days, joined to 2,523 memory creation dates. Reported age-specific rates were 0.463, 0.144, 0.027, 0.013, 0.0088, 0.0041, 0.0054 reads per memory-day for ages 0–1, 1–3, 3–7, 7–14, 14–30, 30–60, and 60–90 days. Old feedback memories were read at 0.027 per memory-day versus 0.0021 for project memories. This is observational evidence under the existing retrieval policy, with a short log window and an explicit feedback-loop caveat in the source.

Sources: [salience.py](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/salience.py), blob `6a304d44b4e4d0a82083f6f46895243d6c31bbfc`; [RECENCY_KERNEL.md](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/RECENCY_KERNEL.md), blob `17561d7b6256ac5345e7e679e6bbf386d7731dd3`.

### 4.2 Learned association weights

The coactivation fold retains at most 40 distinct memories from a session. At a valid fold, existing weights decay by 0.98, and a pair co-read in a session of size \(n\) receives increment \(\min(1,6/n)\). Edges below 0.5 are pruned. Logs with fewer than two memories do not induce a decay. Orphan logs older than six hours can be folded by a later session.

Thus a source-faithful abstract update is

\[
w_{ij}^{+}=0.98w_{ij}+
\sum_{\text{new foldable sessions }s}
\min(1,6/n_s)\mathbf1\{i,j\in s\},
\]

followed by the floor rule. The decay is **per fold event, not per unit of clock time**. More active fleets therefore forget unreinforced associations faster in wall-clock time. This is a useful Pseudo-Cognitive Dynamics question: compare event-based and time-based forgetting under changing fleet size.

The implementation locks, atomically replaces the TSV, and binds exactly-once receipts to session-file identity. A crash after graph promotion but before deleting the log should not count the same co-reads twice.

The compiled graph combines wiki links with weight 1.0 and learned coactivation with coefficient 1.6, plus evaluated orphan, series, and keyword attachment edges. Substrate pages such as the main index or large mistake ledger are excluded as false hubs.

Sources: [coactivation_end.py](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/coactivation_end.py), blob `f8a8d62a7a3e88506de9232e0fffd43120e85726`; [build_spread_edges.py](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/build_spread_edges.py), blob `fbe6ef2db51b768c06e43cf4bdd3e290f2d0b3b1`.

### 4.3 Spreading activation

The actual live general-brain hook is `spread_recall.py`, not the separate on-demand `spread.py`. Live propagation uses two hops and degree-normalized flow:

\[
f_{i\to j}^{(h+1)}
=0.5\,a_i^{(h)}\frac{w_{ij}}{\sum_k w_{ik}}
(1+0.4\,s_j)\,\gamma_j,
\]

where \(s_j\) is mistake severity and \(\gamma_j\) is an optional named-topic gain (3.0 for a severe mistake, 1.7 for ordinary topic information; otherwise 1). The accumulator records the strongest contributing bridge so a surfaced association can be explained.

The hook seeks a non-obvious association: it excludes seed memories and near-duplicates of lexical hits, requires salience and a margin, uses semantic reranking when an admissible embedding artifact exists, routes superseded records to current ones, and applies per-item/per-session repetition limits. The default nominal activation floor is 0.16, divided by a connection-gain setting 2.0 at the speak gate; normal winner ratio is 1.175, and severe-scar ratio 1.075. These thresholds are engineering choices. Doubling every stored edge weight cannot increase flow in a degree-normalized walk because numerator and denominator scale together.

The September-22 source reports a long-session concentration problem: 4.7% of sessions received 65% of associations, with one receiving 195. The new rate cap permits the first six under ordinary item dedup, then spaces successive associations by 10 minutes up to 12, 30 minutes up to 20, and two hours thereafter. A replay reportedly retains 55% of rows while leaving 91% of sessions unchanged. Label this as historical replay of delivery logs; it is not a proof of improved mathematical accuracy.

Source: [spread_recall.py](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/spread_recall.py), blob `4dad1833342feff48dc59074c1d575f1324f707f`.

### 4.4 Feeling-of-knowing and calibrated prediction

`fok_probe.py` checks index descriptions and filenames before reading complete memory bodies. It uses distinctive words, bounded typo correction, a cluster threshold, and salience only as a rank tie-break. It can signal absence for requests needing an exact factual answer. It is expressly silent on mathematical arguments because the proof-specific layer is more relevant there. Its output should be described as corpus accessibility, never “the model knows the answer.”

`predict.py` scores dated resolved forecasts using the Brier loss \((p-o)^2\) and realized self-information \(-\log_2 p_o\). Per-scope calibration shrinks the hit rate toward the global base rate with strength 4, \((h+4g)/(n+4)\), and labels scopes with fewer than three resolved forecasts provisional. These are feedback/calibration mechanisms, not proof probabilities for theorems.

Sources: [fok_probe.py](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/fok_probe.py), blob `aebbe87ca68093942d206302aa7ebce4662de803`; [predict.py](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/predict.py), blob `c923f72d1a315ba461168165fe5588f320959727`.

## 5. Scars, mistake layers, and instincts

A scar is best defined operationally as a persistent, high-priority record of an adverse outcome and the condition that produced it. An instinct is a compiled reminder/check activated by cues. Neither requires literal feeling.

The broad layer distinguishes recognition cues from stronger action hazards. It matches text and graph associations, ranks by charge and measured precision, limits the number displayed, accounts for supersession, and backs off repeated warnings. Current `MAX_FIRE=2`. It records whether a warning came from regex, graph, or forward feed; such attribution is essential to evaluate each mechanism separately. Optional graph/deny lanes require explicit enable markers; their existence in source is not proof of activation.

Math-specific `MistakeRecord` requires claim ID, mistake class, minimal failing step, cause, repair steps, prevention action, optional counterexample, and affected assumptions. Classes include arithmetic, domain, quantifier, sign, limit interchange, unjustified implication, hidden assumption, formalization mismatch, citation mismatch, and numerical instability. `ReflexRecord` requires cues, ordered actions, required evidence, stop condition, and source mistake IDs. The graph edges are typed warnings (`fails_under`, `triggers`), and neither record changes truth status.

Concrete mathematical triggers include: prove every denominator nonzero; check roots for branch/sign/extraneous solutions; name and verify a convergence theorem before interchanging limits; write quantifiers and negations explicitly; do not promote finite numerical tests to a universal theorem; inspect the exact source and its scope; compare Lean statements with prose.

The general mistake-family study is unusually useful as a negative finding. On 91 parsed corrections, Louvain returned 11 groups (nine without reflex labels), but modularity was inside a degree-preserving null's noise (reported z about -0.9). Thus the families organize the ledger; they were not demonstrated natural classes. Of 36 corrections without an explicit reflex label, 24 were novel singleton cases and 12 belonged to already-covered families. Turning every singleton into a live warning would create noise. The proposed response is to watch for recurrence, not manufacture a new instinct immediately.

Sources:

- [instinct_prime.py](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/instinct_prime.py), blob `b845b98f1718b4b2ff4ade5781fa9d40f2293a4f`.
- [MISTAKE_GRAPH.md](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/MISTAKE_GRAPH.md), blob `ad7c5b58ca1e14aac8f41cac378ad5e3e287142b`.
- [mistakes.py](https://github.com/yspennstate/math-research-brain/blob/a4c99b43a044c127787c26997ed942f41591aac6/src/math_brain/mistakes.py), blob `15bd4fbac44cf5d2ad61729197a0c32ec1a1293a`.
- [triggers.toml](https://github.com/yspennstate/math-research-brain/blob/a4c99b43a044c127787c26997ed942f41591aac6/config/triggers.toml), blob `b4234ffb6500902c3096ca7b9c6a891cda9dac63`.

## 6. Mathematical retrieval differs from general association

The typed math store supports stable logical IDs and immutable content-derived revisions, with exact source identity, assumptions, scope, evidence and disposition. A modification to any of these creates a new revision. This makes stale claims and corrections inspectable.

The math retrieval engine derives Unicode-normalized lexical tokens, abstract mathematical symbols and alpha-renamed formula fingerprints. The basic direct score combines lexical, symbol, formula and optional semantic channels; graph support and warnings are separately traced. Negative edges receive positive visibility but negative signed trace, so refutations are surfaced without being counted as proof support.

**Discovery mode** may use analogy, semantic links, historical revisions and cross-brain bridges. **Proof mode** excludes those loose connections. **Exact dependency closure** follows only directed `depends_on` edges and rejects cycles/missing reachable nodes. This is a valuable architectural separation: pattern recognition proposes a route; a proof depends on explicit admissible premises.

Formula normalization is notation matching, not symbolic equality checking. In particular, alpha-renamed string fingerprints are not proofs of equivalence. The semantic module is opt-in (environment `MATH_BRAIN_SEMANTIC=1`), uses prebuilt 384-dimensional normalized BGE-small vectors, and scores a query by positive standardized cosine deviation, \(\max(0,(\cos-\mu)/\sigma)\), limited to a top-K set. The source says cold model loading is about five seconds; this is not a measurement in the present environment.

The experimental live `math_sense.py` additionally uses a mathematical gate, BM25 prefilter, card reranking, short-question-aware thresholds, limited campaign slots, and compact context rendering. Defaults include 3,000 characters for a block and 480 for a statement; thresholds vary with query self-score. It explicitly labels population nodes curated-secondary/unverified. Serving a theorem card is therefore a retrieval event, not a verification event.

Sources:

- [retrieval.py](https://github.com/yspennstate/math-research-brain/blob/a4c99b43a044c127787c26997ed942f41591aac6/src/math_brain/retrieval.py), blob `c3a89d5af1a00594b770b3951cd333bc59b4f4e9`.
- [semantic.py](https://github.com/yspennstate/math-research-brain/blob/a4c99b43a044c127787c26997ed942f41591aac6/src/math_brain/semantic.py), blob `56398599e722d5db452a00c3604bcb691811c047`.
- [math_sense.py](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/math_sense.py), blob `b2a0a8bc424e03ccc60e307084b0d4f3025b6f55`.

## 7. Consolidation, dreaming, and mathematical truth

The general brain uses scheduled background scripts to produce an agenda, then a headless model session to synthesize gists, add links, examine scars, resolve questions, and preserve a journal. The terms slow-wave and REM express distinct operating modes inspired by sleep literature; they are software workflows.

The mathematical package is stricter. `consolidate` is a pure, deterministic function returning quarantined review proposals. Slow-wave-style proposals prioritize negative-edge conflicts (100), reflex rehearsal (80), missing evidence (70), isolated nodes (40), and high-degree hubs (30). REM-style matching uses abstract mathematical tokens and shared formula fingerprints to nominate analogy reviews, with explicit posting and candidate budgets. Every proposal has `can_promote_truth=False`; calling `as_verification_evidence` raises an error.

This separation prevents the recurrent failure in which a model-generated summary gains authority merely by being stored and recalled repeatedly. Background synthesis can create candidate mathematics, but its proof obligations still need independent checking.

The general `reconsolidate.py` uses surprise and an age/type/salience strength heuristic to suggest leaving, branching, awaiting corroboration, or updating a memory. That policy must not be imported as a theorem-verification rule: a valid counterexample refutes a universal claim regardless of how old or important the old memory is. Mathematical revision should follow exact evidence and scope, as the math-specific architecture requires.

Sources: [consolidation.py](https://github.com/yspennstate/math-research-brain/blob/a4c99b43a044c127787c26997ed942f41591aac6/src/math_brain/consolidation.py), blob `138e86a1f200f6c6ba55dc40e9f25b3543b1f9f0`; [retrieval-and-consolidation.md](https://github.com/yspennstate/math-research-brain/blob/a4c99b43a044c127787c26997ed942f41591aac6/docs/retrieval-and-consolidation.md), blob `e2c42bde4f5b6c6a0244436c37434414b3886284`; [reconsolidate.py](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/reconsolidate.py), blob `04f15486109f9e56ee8576ffe2f1eed030bd580a`.

## 8. Coordination and Claude connectivity

The agent mesh provides atomic resource claims, heartbeat/liveness, expiring leases, messages, acknowledgements, task assignments, and handoffs using SQLite. It distinguishes ephemeral progress from durable memory. General documentation says durable lessons are promoted through `brain.py remember` using a cross-process lock and atomic index update.

The separate global workspace has salience/recency-ranked posts and an intent ledger to reduce duplicate or abandoned work. It is documented as a shared present-tense stream, with a roughly thirty-line rendered capacity and kind-dependent decay. However, its WIRING.md still says “NOT wired,” and neither the inspected dispatcher registrations nor inspected wake file contains its hook name. Source code existence is confirmed; current Claude broadcast deployment is **not established by these sources**. It may be supplied elsewhere, so absence here is not proof it never runs.

A precise paper should distinguish:

1. permanent knowledge sharing through committed files and the structured brain;
2. transient lease/mailbox coordination on a live machine;
3. scheduled workers exchanging durable artifacts through GitHub;
4. actual context injection, which requires compatible runtime hooks and observed delivery.

Sources: [agent_mesh/README.md](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/agent_mesh/README.md), blob `21bb05b096053da2a4fc8beb8bb35b75aead348d`; [global_workspace/README.md](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/global_workspace/README.md), blob `a49d3c279bb0f17d8c176e7eda8be39d4290183b`; [WIRING.md](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/global_workspace/WIRING.md), blob `a81d4ba65f8d71b06ec7ebc12c1bc89e7cbd48bb`.

## 9. Material correctness findings for the collaborating Claude

### A. A deployed-path failure invalidates naive benchmark-to-production inference

At the top of `math_sense.py`, the September-22 diagnosis states that from September 15 20:25 through September 22 19:35 every real-session invocation failed to import NumPy under `python -s`: 710 silence rows, no live theorem cards, while plain-Python harness tests worked. The repair restores the user site if NumPy is missing under that invocation mode.

Use wording such as **“repository-recorded deployment outage, repaired in source on September 22; runtime recovery requires a delivery receipt.”** Do not imply the week's successful offline/harness tests prove those sessions had Math Brain context. A useful test hierarchy is import check → retrieval check → exact runtime invocation → delivered-context receipt → downstream mathematical performance.

### B. Recency semantics drift between salience and tier classifier

`consciousness.py` has `RECENT_R=0.72` described as roughly two weeks under \(\tau=45\). It now imports default salience with \(\tau=1.3\). Hence the corresponding age cutoff is

\[
-1.3\log(0.72)=0.427\text{ days},
\]

roughly ten hours, rather than two weeks. Its old-flat-stub threshold \(R<0.40\) similarly means older than 1.191 days, instead of roughly 41.23 days under the original kernel. Rounded recency introduces small boundary shifts but does not alter the mismatch. Linked, feedback/user, and other exception paths remain protected; the effect concerns eligible uncurated short project stubs/logs.

Recommended repair: express tier decisions in explicit age-days using a shared date function, or derive the threshold from the intended age cutoff and current kernel. Test one-day, two-week, and six-week unlinked stubs and preserve special handling for substantive memories. No fix was applied by this agent.

Source: [consciousness.py](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/consciousness.py), blob `a5a907e2341151bf029d244959b839147ec1afae`.

### C. Semantic guard ordering deserves correction before strong contamination claims

The math retrieval guard filters eligible IDs, but opt-in `semantic.standout_scores` computes mean/std and top-K over the **whole vector artifact**, then applies allowed node IDs. Its own comment notes candidate dilution. Thus excluded records can still affect normalization/top-K if they exist in the artifact. This does not establish answer leakage in any actual run, because the artifact may contain only permitted data. It does mean “all filtering happens before scoring” is too strong for this opt-in path.

Recommended repair: restrict the vector population by allowed IDs before mean/std/top-K, with a fixture showing that adding excluded test records cannot change eligible scores or ranking. Preserve the distinction between benchmark isolation and general retrieval quality.

### D. Current math coordination policy and old population-hook behavior must be separated

Current math README says native installation remains suspended, the repository is the coordination archive, and native learned-memory ingestion is not claimed by current research files. The broad source nonetheless implements a hook serving a local population database. Both statements can be true: a historical/experimental population integration does not prove approved ingestion of newly produced mathematical research. The paper should state the version and deployment/corpus condition used by each reported test.

### E. Deterministic does not mean zero token cost

The global-workspace design says deterministic rendering cannot “cost anything.” Correct interpretation: no model API invocation is required for the renderer. Injected text is still model input; repeated cached text may have a distinct billed cost; retrieval consumes CPU/time; background model consolidation consumes tokens. Count each ledger category separately. Never estimate total construction effort from repository size alone.

## 10. What is supported, and what should remain a research question

Supported by inspected source:

- external-memory persistence and selective context injection;
- typed mathematical records with revision/provenance/evidence separation;
- independent discovery and proof dependency routes;
- concrete mistake/reflex structures;
- guarded replay that cannot self-promote truth;
- mathematical statement cards with declared unverified provenance;
- calibrated warning/recall thresholds and log-based refinement;
- explicit deployment failures, rollbacks, and counterexamples to proposed improvements.

Not supported by architecture alone:

- a causal percentage gain on mathematical tests;
- a construction-token grand total;
- a claim that every scheduled worker actually consumed native memory;
- a claim that the brain solved an old open problem;
- an inference that any named theorem was Lean checked;
- general humanlike cognition or consciousness;
- superiority over all simpler retrieval or prompting baselines.

Strong Pseudo-Cognitive Dynamics research questions include optimal context allocation under noise/cost; rate-stable learning across changing fleet size; separating importance from truth confidence; stable retrieval under graph growth; formal non-promotion guarantees; retention of negative evidence; unbiased evaluation under evolving memories; and exact attribution of a result to retrieved material rather than additional compute.

The architecture's likely value is **reduced repeated work, more visible proof obligations, faster access to relevant counterexamples/lemmas, and auditable continuity**. Causal usefulness must be measured, including harmful recalls and token overhead. This is a serious systems/research contribution even when it does not establish a famous conjecture.

