# Research catalogue: scope, provenance and interpretation

This supplement supports the research chapter of *Mathematics of Pseudo-Cognitive Dynamics*. It preserves the discoverable mathematical intake and selected research cases at frozen repository snapshots. A catalogue entry is not a proof, and an association with the project is not evidence that memory caused an improvement.

## Files

| File | Contents |
|---|---|
| research_catalog_complete_1168_ids.csv | One final observed row per problem ID, with exact inherited statements/statuses and provenance |
| research_catalog_source_records.json | All 1,391 original record objects from eight nonduplicate queue files, including earlier versions |
| research_catalog_bibliographic_records.json | All record objects from six source registers, preserving acquisition and reading metadata |
| research_catalog_manifest.json | Frozen commit, queue counts, identity and date policy |
| research_proofnet_directory_inventory.csv | All 87 top-level ProofNet directories, including research, administration, historical renamings and aggregate workstreams |
| research_chronology_reviewed_cases.csv | 29 selected case groups ordered by their qualified documented dates; undated exact targets appear last |
| research_catalog_findings.md | Detailed mathematical case notes, scope corrections, chronology and pinned source links |
| research_catalog_validation.json | Recomputed counts, projection consistency checks and local-file SHA-256 hashes |

## Counts and duplicate policy

The main mathematical archive is yspennstate/math-open-problems at commit b4745ece98fa3839cf7afe35d829d08384c815b4. Eight distinct queue blobs contain 1,391 physical JSON records, 1,168 unique problem IDs, and 223 additional version records. The repository has seven further files under probability_1000/ whose Git blob hashes exactly match the corresponding root intake files; these mirrors are not counted twice.

| Queue | Records | Unique IDs |
|---|---:|---:|
| probability_campaign_2026_09/codex_20h_20260906/problems.jsonl | 611 | 495 |
| probability_1000_intake_claude_20260907/problems.jsonl | 160 | 160 |
| probability_1000_intake_D_20260908/problems.jsonl | 102 | 102 |
| probability_1000_intake_E_20260908/problems.jsonl | 115 | 113 |
| probability_1000_intake_F_20260908/problems.jsonl | 154 | 140 |
| probability_1000_intake_G_20260910/problems.jsonl | 15 | 15 |
| probability_1000_intake_H_20260914/problems.jsonl | 34 | 25 |
| probability_1000_intake_I_20260914/problems.jsonl | 200 | 118 |
| **Total** | **1,391** | **1,168** |

No problem ID appears in multiple queue files in this inspected set. Repeated rows are historical updates within a queue. Different IDs can still describe overlapping mathematical problems. The 993 nonempty inherited deduplication keys are heterogeneous and do not establish a precise distinct-problem count. Neither the unique-ID count nor any status count is a solved-conjecture count.

## Canonical CSV columns

- **problem_id, title, statement:** the last observed raw record for that ID in the preserved source order.
- **source_id, source_title, source_url:** inherited identifier and matched source-register metadata where available. An arXiv URL is reconstructed only when the source ID explicitly encodes an arXiv identifier.
- **source_publication_year_proxy:** a convenience field derived from an arXiv identifier or a year in a source ID. It can describe a survey, revision, or source publication. It is **not** the original problem date.
- **problem_origin_year_verified:** blank throughout this broad machine projection. Primary-source chronology is supplied only for individually reviewed cases in the separate chronology.
- **historical_status_inherited, current_status_inherited, result_status_inherited, verification_inherited:** original source labels preserved without mathematical endorsement. They can be stale, inconsistent, overly broad, or superseded by later audit or external literature.
- **review_status_this_paper:** every canonical entry is marked SOURCE_REPORTED_UNVERIFIED. This does not say the source claim is false; it says this catalogue projection is not an independent proof audit.
- **source_record_versions:** number of raw rows retained for the ID.
- **source_catalog_path, source_catalog_blob_sha, source_record_number, source_commit, source_record_url:** recover the exact upstream file and record position.
- **statement_caveat, proof_file, status_search_json, dedup_key_inherited, admitted:** original qualifying and routing data. Nested objects are JSON strings in the CSV.

“Final observed row” means final among the downloaded append-only intake records. It does not mean the latest mathematical truth: later papers and adjudications sometimes correct intake records without rewriting them. Examples discussed in the case notes include a2026 external copula resolution, the minimal-spanning-forest correction, the stale gossip-game scope and corrected Janson condensation statements.

## Record integrity versus mathematical verification

The JSON files preserve complete record objects and metadata; they are reserialized containers, not byte-for-byte copies of the upstream JSONL files. An upstream Git blob SHA identifies the original source file. The separate local SHA-256 values identify the delivered supplement files. These two hash roles must not be confused.

The local validation recomputed all counts and checked that canonical titles, statements and inherited result/current statuses match the final observed raw records. It also checked version counts, unverified annotations and chronology ordering. This establishes internal consistency of the supplement. It does not verify the mathematics, novelty, peer review, native memory ingestion or counterfactual impact of Math Brain.

## Chronology and attribution

The29-row chronology groups selected cases for readability. Dates are labelled as original preprint, documented formulation, source publication, historical background or owner-specified new target as appropriate. A source date is not silently promoted into the first historical appearance of a conjecture. The1991 Sidorenko publication was received in1990; equivalent older formulations are not independently dated here. Lyons entropy concavity is verified in arXiv version1,2002, as Conjecture8.2, later renumbered9.2 in2003. The Arnold-inspired project has a2026 exact target despite its1964 background. The Bass–Quillen run itself could not recover the exact original specialization, so that exact target is undated.

The distinction between a parent problem and a restricted theorem is retained. A finite certificate may prove every case in a displayed finite class or an exact polynomial inequality on a parameter domain, while leaving the universal source conjecture open. A retrieved counterexample to a proposed lemma does not automatically refute the parent conjecture.

The evidence supports scoped mathematical utility, correction retention and selected actual retrieval traces. It does not supply a controlled estimate of theorem-solving improvement across the whole catalogue.
