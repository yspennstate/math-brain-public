# Research catalogue and chronology: Mathematics of Pseudo-Cognitive Dynamics

Evidence review dated 23 September 2026. This is a research assistant's source-grounded dossier for the parent manuscript, not an independent verification of every proof in the project.

## 1. The defensible conclusion

The repositories contain a substantial mathematical research programme: explicit restricted theorems, exact finite certificates, candidate resolutions of named source questions, mathematical counterexamples, corrections of previously accepted arguments, and still-open flagship problems. They do **not** establish that Math Brain solved every listed problem or caused the research progress. A repository association, a recorded memory lookup, a changed mathematical step, and a controlled improvement over an otherwise identical run are four different evidential claims.

The clearest value demonstrated by the mathematical records is **preserving the scope of a result and the reasons a tempting route failed**. Examples include downgrading a false Rademacher circuit lemma after a Pasch counterexample, retaining FEI counterexamples against attractive potential functions, correcting an all-balls condensation assertion to a subsequential near-total theorem, and separating a Gaussian-mixture quadratic-form theorem from the unrestricted product-density conjecture.

The main Math Brain installation currently distinguishes shared repository handoffs from verified native ingestion. The parent paper should retain the project's own WITHOUT_VERIFIED_BRAIN distinction where runtime retrieval and subsequent receiver use are not evidenced. Most research items below have research-ecosystem provenance, not a causal ablation.

## 2. Frozen evidence and complete discoverable supplements

Three repositories were used:

| Repository | Frozen commit | Role |
|---|---|---|
| yspennstate/math-research-brain | a4c99b43a044c127787c26997ed942f41591aac6 | Current FEI/QFORM state, task memory and handoff system |
| yspennstate/math-open-problems | b4745ece98fa3839cf7afe35d829d08384c815b4 | Research papers, append-only queues, source records, ProofNet runs and audits |
| <private-repo> | bcff9346b68959f4cf330fdf9ca0e64a21c77d3e | Earlier mathematical research archive |

The complete inspected queue supplement contains **1,391 physical problem records in eight queue files, representing 1,168 distinct problem IDs**. There are 223 additional version records. These are not 1,168 independently established distinct conjectures and emphatically not 1,168 solved problems. There are 993 nonempty inherited deduplication-key values; some are coarse, some encode IDs, and some different IDs may represent the same mathematical question, so that field is not a reliable mathematical distinctness count. The ProofNet top-level directory inventory contains **87 directories**, including renamed/reused track IDs, administration and aggregate workstreams. The historical name ProofNet24 does not describe a fixed present inventory of exactly 24 distinct problems.

Deliverables in the shared workspace:

- research_catalog_complete_1168_ids.csv: final observed record per ID, with original statement, inherited statuses, source URL, exact queue path/blob, version count and explicit SOURCE_REPORTED_UNVERIFIED annotation.
- research_catalog_source_records.json: all 1,391 raw records, including earlier versions.
- research_catalog_bibliographic_records.json: six full source-register files, preserving original bibliographic and acquisition metadata.
- research_proofnet_directory_inventory.csv: all 87 top-level ProofNet directories, file/run counts and pinned URLs.
- research_catalog_manifest.json: counts, source commits and projection policy.

The CSV's source-publication-year proxy is deliberately separate from original problem date. A 2025 survey may restate a conjecture from 1933. Unknown origins remain unknown; no false exact age is computed. The canonical row projection is the last observed row per problem ID within these downloaded files, not a claim that every later proof or literature development has been reconciled into the intake queue.

## 3. Chronological overview of deeply investigated and prominent tracks

Age is approximately 2026 minus the displayed year and refers to the **documented source formulation or source publication**, as qualified. It is not elapsed time during which the project itself worked on the question. Several primary sources are recent restatements of older folklore; this table makes that distinction explicit.

| Documented date | Approximate age | Problem or track | Scope and status supported by this review | Mathematics and scientific value |
|---|---:|---|---|---|
| 1933; determinant background 1893 | 93 years since explicit Paley formulation | Hadamard existence, matrices H of every order 4m with HHᵀ=4mI | Full conjecture OPEN; inspected P15 run credited no new unresolved order. Its then-current target was 2092. Reconstructed externally known orders receive no novelty credit. | Exact multiplier-orbit and row-sum obstructions sharply eliminate restricted circulant construction families. Useful finite search compression, not universal nonexistence or existence. |
| 1950 | 76 years | Hadwiger–Nelson chromatic number of the plane | Full problem OPEN. Inspected run's tracked smallest certified 5-chromatic unit-distance graph stayed 509; no 6-chromatic candidate. | All 1,175 exact squared-distance-three pairs in the Parts graph admitted equality-constrained five-colourings. This exhausts a particular forced-difference gadget route and records a reusable negative result. |
| 1964; conjecture attribution has historical nuance | about 62 years | Černý reset-word conjecture rt(A)≤(n−1)² | OPEN. Inspected track complete-size metric remained 7 for its exact-three/exact-four-letter scope. Complete four-letter n=8 cell was unpaid. | Canonical augmentation and theorem-backed extension sieves reduce exhaustive automaton verification while preserving the full class. Restricted subclass exhaustion does not improve the full-n metric. |
| 1964 background; exact project target 2026 | 62 years of background, not a 62-year-old exact target | Arnold diffusion / Universal Windowed Arnold Diffusion | Broad archive reports abstract all-tail/Hamiltonian bridge results; Global Arnold Window Implantation remains a conditional hypothesis. No full general diffusion theorem established here. | Separates local implant constructions and shadowing/transition machinery from the global existence bridge still required. |
| 1975 | 51 years | Binary longest common subsequence constant γ₂ | OPEN. Current project bound is source-reported; exact constant unknown. | Finite-state dependency-preserving bounds. Reported upper 0.8262759427622826; latest microscopic strictification about 1.07×10⁻⁸⁰ is not a material practical gain. |
| 1970s historical context; exact original specialization unrecovered | not safely assigned | Bass–Quillen and Quillen localization/freeness | OPEN. The run explicitly could not recover the original parameter/ramification specialization; its four-dimensional laboratory is conditional. | All-exponent kernel desaturation and an oriented reflexive boundary lattice isolate the remaining low-rank obstruction in codimension at least three. Stable K₀ or localization freeness is not silently substituted for polynomial extension. |
| 1991 original publication; received29May1990; earlier circulation not established here | 35 years from publication | Sidorenko for H=K₅,₅ minus C₁₀ | Restricted equal-three-block regular-host theorem has exact computer-assisted certificate; general graphon target OPEN. | t_H(A)≥1+(725117/3179904)ρ⁴ and ≥1+(1/20)‖A−1‖⁴₂ on a compact normalized three-block domain. Exact Bernstein coefficients certify a continuum, not just sampled points. |
| 1994 chapter dates | about 32 years | Aldous–Fill arc-transitive OP7.27; flow-diameter OP4.49(ii); related hitting/cover problems | Candidate refutations of precise source formulations; no blanket resolution of all Aldous–Fill or cover-time questions. | Cycle blow-ups give exact hitting/commute counterexamples. Ramanujan cones make a flow/relaxation/diameter ratio unbounded. The counterexamples distinguish universal constants from a previous constant-two example. |
| 1994 source used; conjecture has earlier history | at least 32 years in this source | Baum–Connes–Higson coefficient-free assembly | Universal target OPEN. Frozen C₂ wreath F₂, degree-one subgroup already saturated at rank 2 and is externally known. | Recovered existing K-theory computation proves a third independent class cannot exist. Ending a saturated task is a scientifically valuable correction, not a new proof of Baum–Connes. |
| 1995 documented folklore | at least 31 years | Sharp Rademacher singularity probability ∼2n²2⁻ⁿ | Full sharp asymptotic OPEN in campaign. The weaker exponential-base theorem is an external known result and must not be confused with sharp prefactor. | Entropy-rigidity, residual rank and quotient-congestion lemmas, exact small-support geometry, typed dependency graph; Pasch counterexample invalidates a previously accepted route. |
| 1996 | 30 years | Fourier entropy–influence (FEI) | Full uniform-cube conjecture OPEN. Read-once AND/OR/NOT bound H≤6.4573I is repository certified in its restricted class. | Exact composition identities, Jensen–Shannon and conditional entropy, interval certificates, counterexample-guided potential design and source-aware restrictions. |
| 1996 | 30 years | Nonamenable Cayley percolation p_c<p_u | Universal target OPEN. Project reports a quantitative selected-generator SL_n(Z) family for n≥5. | Explicit branching/expansion estimates can separate thresholds in a concrete family; this does not handle every nonamenable group or generating set. |
| May 1999 manuscript; publication 2000 | about 27 years | Pairwise negative correlation for uniform forests | General conjecture OPEN. Project reductions and small-family proofs only. | Partition-function inequality N_eN_f−NN_ef≥0, deletion/contraction, response matrices. Forest measure must not be replaced by spanning-tree measure, where stronger properties are known. |
| 2002 original preprint; 2003 journal | 24 years | Lyons determinantal entropy concavity | Full positive-contraction conjecture OPEN. Restricted Fourier/four-site theorems and explicit refutations of stronger auxiliary claims. | Hessian splits into Fisher information and signed curvature; exact rational/log and polynomial certificates expose the true remaining determinant condition. |
| 2005 | 21 years | Bradley strong-mixing Question 7 | Repository records a refutation of the literal question. This review has not rederived the full memo; retain candidate/source-reported status. | Counterexample/quantifier control; no broad assertion that all strong-mixing structure questions were solved. |
| 2008 preprint; 2010 publication; Kalai restatement 2018 | 18 years from preprint | Spectral entropy of planar percolation (GPS open problem / Kalai Conjecture 8) | Repository/user preprint reports H(f_R)=O(R²α₄(R)); scoped candidate result, not full FEI. | Quadtree coding plus spectral-sample estimates turn multiscale geometric structure into an entropy bound. |
| 2011 preprint; 2012 survey | 15 years from preprint | Janson zero-radius condensation, published Problem19.41 / preprint18.40 | Latest draft claims a negative answer via near-total-condensation subsequences for all full admissible positive-density paths. Positive-boundary-mean Problem19.40 remains untouched. | Occupation-count insertion preserves the entire small-box partition function; deterministic record margins give uniform windows and sharp sampling criterion. |
| 2011–2012 same survey | about 15 years | Other Janson allocation, degree, width and condensation questions | Mixed candidate proofs, counterexamples and imported known height results; source numbering and hypotheses essential. | Rare atoms, overshoot and support gaps show why moments or zero radius alone need not enforce a proposed global limit. |
| 2013 | 13 years | Burdzy–Scheutzow Problem7.5 | Repository says affirmative filling-scheme resolution; novelty limited by related Last–Mörters–Thorisson 2011 theory. | Stationary balancing/transport construction. This review does not certify a new theorem. |
| 2017 preprint; 2018 paper | 9 years | Sharp free-Brownian unimodality diameter threshold, Hasebe–Ueda Problem3.3 | Research draft claims sharp t≥D², two-atom extremizer; full independent proof/novelty audit not performed here. | Cauchy-profile curvature and two-atom extreme-point reduction combined with Biane subordination. Exact algebraic cores and analytic bridge have different verification scopes. |
| 2018 preprint; 2020 paper | 8 years | Thévenin degree-count Gaussian-limit questions | Latest draft claims counterexamples for subcritical finite-third-moment/no-exponential-moment and critical infinite-variance regimes. | Two nearby giant-degree alternatives create a symmetric mixture of Gaussian limits. Moment assumptions do not erase conditioning-induced tail geometry. |
| 2020–2021 | 5–6 years | Multiplicative free-Brownian unimodality / Problem4.7 | Repository records two-atom counterexample; source-reported scope. | Explicit two-atom transforms disprove a proposed general monotonicity property; separate from additive free-Brownian threshold. |
| 2022 | 4 years | Leskelä / Ross Markov-modulated queue comparisons | Some literal conjectures refuted; another three-state speed comparison established in the manuscript. | Cyclic environmental effects and supermodular order reveal limits of monotone comparison heuristics. |
| 2022 | 4 years | Pollett quasi-stationary distributions | Repository records rank-two counterexample; not independently rederived here. | Low-rank exact construction isolates what the proposed order/limit statement was missing. |
| 2025 | 1 year | Salez Cayley cutoff/product condition | Literal abelian-Cayley target retired after discovering author's later manuscript already covered the counterexample. Bounded-degree cutoff conjecture remains OPEN. | Literature-aware novelty correction; arbitrary abelian families cannot stand in for bounded-degree transitive expanders. |
| 2025 | 1 year | Agresti–Veraar critical Allen–Cahn/maximal regularity Problems4/5 | Candidate endpoint counterexample via Bessel-4 construction; actual analytic scope and Lean core require separate evaluation. | Shows exact stochastic endpoint/regularity hypotheses matter. |
| 2025 | 1 year | Catalano–Lavenant quadratic-Wasserstein copula extremizers | Brain-assisted attempted route logged 12Sep2026. Independent Ansari preprint submitted 20Sep2026 claims full resolution. Credit the external paper, not Brain. | Sharp bound W₂²(C,Π)≤1/10, equality for Fréchet–Hoeffding extremizers; conditional comonotonicity and convex order. |
| July–September 2026 | weeks to months | Fresh urn, Lévy drift, frog, random-tree and heavy-tail queue intakes | Mixed narrow refutations, reductions and pending proofs. Source year is not automatically first origin. | These illustrate fast intake and correction; raw queue status remains unverified. |
| Owner formulation 22Sep2026; external original date unknown | 1 day in supplied handoff | Three-eigenvalue bounded-density quadratic forms (QFORM) | Unrestricted indefinite arbitrary cap-one product inputs OPEN. New 23Sep manuscript proves restricted semidefinite and Gaussian-mixture results with explicit conditions. | Rank-two Riesz potentials, determinant/minor averaging, spectral spread, physical-coordinate conditioning and exact correction ledger. See §8. |

### Primary historical sources checked

- Paley, On Orthogonal Matrices, April1933, pp311–320: [original publisher DOI](https://onlinelibrary.wiley.com/doi/10.1002/sapm1933121311). Distinguish this explicit existence formulation from Hadamard's 1893 determinant background.
- Nelson's 1950 question is explicitly dated in [Exoo's primary research paper](https://arxiv.org/abs/1805.06055); [de Grey's 2018 paper](https://arxiv.org/abs/1804.02385) is the foundational 5-colour lower-bound development.
- Černý's original 1964 article is the source in P16; [Don's research paper](https://arxiv.org/html/1507.06070v2) states the conventional 1964 origin. Some histories distinguish Černý's extremal family from Starke's later explicit formulation, so avoid a spurious exact anniversary.
- [Chvátal–Sankoff 1975 original article](https://www.jstor.org/stable/3212444) and [Heineman's research paper](https://arxiv.org/html/2407.10925v1) establish the LCS provenance.
- [Aldous's author-maintained book page](https://www.stat.berkeley.edu/~aldous/RWG/book.html) dates relevant chapters to1994 and gives the suggested2002/2014 citation. Its compilation year is not the birth year of every problem.
- [Kahn–Komlós–Szemerédi 1995 original paper](https://www.jstor.org/stable/2152887) describes the duplicate-row/column singularity asymptotic as folklore. [Tikhomirov's primary exposition](https://www.math.ualberta.ca/~alexandr/travel/AGA4-talks-19/KTikhomirov-SPB-AGA4-19.pdf) distinguishes weak exponential-base and sharp formulations.
- FEI1996 attribution is in [O'Donnell–Tan](https://www.cs.cmu.edu/~odonnell/papers/fei-composition.pdf); [O'Donnell's primary mathematical lecture notes](https://www.math.ias.edu/files/ODonnell_Fourier.pdf) also specify it.
- [Benjamini–Schramm1996 original article](https://projecteuclid.org/journals/electronic-communications-in-probability/volume-1/issue-none/Percolation-Beyond-Zd-Many-Questions-And-a-Few-Answers/10.1214/ECP.v1-978.full) is the percolation source; [Hutchcroft2018](https://arxiv.org/abs/1804.10191) proves the hyperbolic restricted case and states the1996 general conjecture.
- [Pemantle manuscript](https://arxiv.org/pdf/math/0404095) is dated May1999 internally, despite its2004 arXiv upload; [Grimmett–Winkler2003](https://arxiv.org/abs/math/0302185) explicitly points to that earlier forest conjecture.
- [Lyons original arXiv entry](https://arxiv.org/abs/math/0204325) starts2002; [2003 journal article](https://www.numdam.org/item/PMIHES_2003__98__167_0/) and [full paper](https://arxiv.org/pdf/math/0204325) contain Conjecture9.2. The independent audit also inspected [version1](https://arxiv.org/pdf/math/0204325v1), uploaded26April2002 (internal version date25March2002), where entropy concavity is Conjecture8.2 on printed page37. It became Conjecture9.2 in the journal text. [2014 ICM paper](https://arxiv.org/abs/1406.2707) restates it as Conjecture2.6.
- [Sidorenko's original publication](https://www.mathnet.ru/eng/dm804) is dated1991, with received date29May1990 and English translation1992. [Szegedy's primary research paper](https://arxiv.org/pdf/1406.6738) cites a1993 formulation. We use1991 publication in the table without claiming to settle the first circulation date or earlier equivalent Erdős–Simonovits formulations.
- [Bradley2005 survey](https://arxiv.org/abs/math/0511078); [Garban–Pete–Schramm2008/2010](https://arxiv.org/abs/0803.3750); [Janson2011/2012](https://arxiv.org/abs/1112.0510); [Hasebe–Ueda2017/2018](https://arxiv.org/html/1710.08240v2).
- [Ansari20Sep2026](https://arxiv.org/abs/2609.23940) is a new external claimed resolution of the copula extremal conjecture.

Dates without a primary link above are explicitly source-register or historical-context dates and should not receive a precise first-origin claim in the final paper.

## 4. Direct memory-use evidence: useful, but small and observational

Two exact files from probability_1000_attempts_H_20260912 record four retrieval events while attacking G0013:

1. At10:19, math_sense returned Birkhoff–von Neumann; recall returned the intake record and unrelated material. The worker reported no proof change.
2. At10:43, math_sense was silent; recall brought an old scar about reversing the direction of a density statement. The worker reported rechecking that perimeter≥isoperimetric profile provides a lower bound, not an upper bound. **changed_research_step=true**, but no route change.
3. At13:05, math_sense was silent; no change.
4. At13:06, recall returned the worker's own intake and irrelevant Bernoulli content; no change.

One recorded correction cue among four retrieval events is an illustrative trace, not a25% theorem-solving success rate, randomized estimate, or evidence of net token savings. It shows the mechanism the paper calls subconscious-to-conscious promotion: a stored error pattern can become a context-visible sign-check cue. It also shows retrieval noise and silence.

Sources: [BRAIN_USAGE](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/probability_1000_attempts_H_20260912/BRAIN_USAGE.jsonl), [BRAIN_USAGE_q2](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/probability_1000_attempts_H_20260912/BRAIN_USAGE_q2.jsonl).

The later external copula result must be reconciled into the paper. Ansari's20Sep preprint attributes the conjecture to Catalano–Lavenant2025 and claims W₂²(C,Π)≤1/10, equality iff the Fréchet–Hoeffding upper/lower copula. That external development supersedes a queue that still says the target is open; it is not a Math Brain accomplishment.

## 5. FEI: a useful restricted theorem and durable counterexamples

For Boolean f on a uniform cube, let p_f(S)=f̂(S)². Parseval makes this a probability distribution. Its entropy is H(f)=Σ_S p_f(S)log₂(1/p_f(S)); total influence is I(f)=Σ_S|S|p_f(S). The1996 conjecture asks for a universal C with H(f)≤CI(f). No retrieved current source claims a full proof.

The21Sep read-once certificate claims H≤6.4573I for formulas built from AND, OR and NOT with each input used at most once. The proof reduces composition to a two-variable inequality and verifies it by interval certificates. A sharper numerical candidate near6.4547837 is not an established optimal constant. A later margin0.003 certificate attempt failed at a specified degenerate cell (x=4,v≈1.584632, bound≈−9.949×10⁻⁴); the source says the candidate bound itself fails there. It is essential not to promote successful subregions into the sharper full theorem.

Exact restriction and composition identities are valuable because they tell the memory engine what information must survive compression. Under restriction of coordinate i, an entropy decrement separates Jensen–Shannon divergence from weighted binary conditional entropy:

Δ_iH = JS + Σ_S m(S)h(q(S)).

A proposed induction can use a potential Ψ if 0≤Ψ(f)≤KI(f) and a coordinate always satisfies

Δ_iH ≤ C Inf_i(f)+Ψ(f)−[Ψ(f_i=0)+Ψ(f_i=1)]/2.

Summing down the restriction tree would imply H≤(C+K)I. The existence of a universally valid Ψ is the hard mathematical obligation; the displayed template alone does not solve FEI.

Current memory records invalidate potentials0.337/0.34 with an18-input counterexample, unweighted convolution-L₂ payment through a rare-suspension family, and a raw U4 inequality even at a primitive terminal. They retain orientation and bias information that an overcompressed “almost works” summary would lose. This is a clear research value of mistake/scar layers: a prior false induction does not regain credibility merely because its counterexample disappeared from the active context.

Sources: [read-once certificate](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/proofnet24/P03-fei/continuations/2026-09-21-readonce-certificate/README.md), [current shared research](https://github.com/yspennstate/math-research-brain/blob/a4c99b43a044c127787c26997ed942f41591aac6/scheduled_tasks/work/shared/fei-all-team-2026-09-22/CURRENT_RESEARCH.md).

## 6. Rademacher singularity: typed mathematical memory and a failed theorem

The campaign targets P(det B_n=0)∼2n²2⁻ⁿ for iid symmetric signs. The leading event is a repeated or opposite pair of rows or columns. Showing that every other algebraic dependence is negligible at this exact scale is the unresolved task. Knowing only P(singular)=(1/2+o(1))ⁿ does not settle the prefactor.

The local campaign's mathematical graph reaches325 objects and602 dependency edges with no unresolved dependency names in its reported snapshot. Object kinds include37 certificates,16 counterexamples,27 failed routes,49 lemmas,24 open gaps and77 theorem objects. Status counts distinguish79 audited-pass,60 exact-certificate,109 proved,26 disproved,27 open,9 conditional,10 numerical and5 heuristic objects. These are typed database entries, not325 independent new theorems. Earlier97-object and later integration-layer counts must not be added again to the cumulative325.

Concrete reported mathematics includes:

- Entropy-sharpened residual-rank bound d_cb(A)≤9·4^ℓ+ℓ.
- Bounded-congestion quotient dimension dim((R+span W)/span W)≤(2κ+1)L_(Q|W).
- Exact rooted-NAE-cycle fibre geometry, selector/transversality lemmas and small-support classifications.

The universal linear entropy-rigidity bound, connector absorption and final probabilistic transfer are still unpaid. A Pasch counterexample refuted a previously audited-pass claim |D|=r+k for a linear-system class and invalidated its counting consequence by an unbounded factor. The system downgraded those objects and retained the replacement open gap and counterexample. This is stronger evidence of useful correction management than a headline tally of “proved” entries would be.

Source: [campaign mathbrain README](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/probability_1000/sharp_rademacher_campaign_2026_08_18/mathbrain/README.md).

## 7. Lyons determinantal entropy: distinguishing a conjecture from false proof routes

For a finite positive contraction Q, let P_Q be its determinantal-process law and H(P_Q) its Shannon entropy. Lyons asks whether H(P_((1−t)Q₀+tQ₁)) is concave in t. The archive derives its Hessian as a Fisher-information term plus a signed curvature term; that signed term is why an appealing automatic concavity argument is insufficient.

The17Sep continuation proves restricted four-site/Fourier cases, including a sufficient condition Var(N)log(P/O)≤8/5, covering O/P≥1/4; coupling concavity at fixed pair spectral means; and several fixed-mean or co-moving-mean cases. Its certificate collection includes75 coefficientwise polynomial identities and another extension with21 coefficient identities and36 rational checks. Numerical optimizers are separately labelled.

Exact counterexamples refute stronger shuffle, pointwise-resolvent and partial-integral positivity statements. These do not refute Lyons's original entropy conjecture. Their value is to forbid invalid sufficient conditions while leaving the true target intact. A memory graph should encode “refutes proposed lemma L used toward target T”, not “refutes T”.

Source: [Lyons continuation](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/proofnet24/lyons-entropy/continuation-2026-09-17/README.md).

## 8. Quadratic forms: latest23Sep release supersedes older constants

The unrestricted target is a universal bound for the density of Q=XᵀAX+bᵀX+c when X has independent real-coordinate densities≤1 and A is **real symmetric** with at least three eigenvalues of absolute value≥1. Symmetry matters: e_k(A²) equals the sum of squared minors here because A²=AᵀA. The project is explicitly OPEN for arbitrary indefinite symmetric A and arbitrary rough cap-one laws.

The23Sep release, despite a path containing “full-proof-paper”, explicitly says it is a125-page manuscript of partial theorems, complete scoped proofs and remaining endpoint problems. It preserves341 interactive source files,153 selected recent worker reports and full tree inventories. The source documentation distinguishes internal independent derivations from external journal peer review or machine-checked formalization.

### 8.1 New Gaussian-mixture theorem

Suppose X_i=M_i+√T_i G_i, coordinate pairs (M_i,T_i) independent, T_i>0, independent standard Gaussians G_i, and E T_i^(−1/2)≤√(2π). Put

Z_k=e_k(A²)=Σ_(|I|=|J|=k)det(A_IJ)²,

I_k=∫₀∞(1+u^(2k))^(−1/4)du
   =(1/(2k))B(1/(2k),1/4−1/(2k)).

For3≤k≤rank A, the manuscript proves

‖p_Q‖∞≤I_k Z_k^(−1/(2k)),  I_k<k/(k−2).

Thus the three-eigenvalue condition gives a bound **strictly below3** in this class. For deterministic centers, the cap-one Gaussian scale-mixture density condition is exactly E T_i^(−1/2)≤√(2π). Random shifted mixtures need the average component-peak hypothesis explicitly: a bounded mixture can consist of narrow components at distant centers without a bounded average component peak.

The argument conditions on mixture variables, uses the Gaussian determinant characteristic-function formula, expands e_k by Cauchy–Binet into squared minors, and applies weighted arithmetic–geometric mean and independent fractional moments. The weights α_i obey0≤α_i≤2 and Σα_i=2k, making the necessary moment exponents≤2/k<1. These powers are a reusable mathematical insight; arbitrary Gaussian-mixture approximation cannot remove their integrability requirement.

### 8.2 Semidefinite and other scoped results

The current manuscript proves ‖p_Q‖∞≤17100/λ₃(A) for positive semidefinite A, and the corresponding negative-semidefinite bound, independently of dimension/rank and with arbitrary affine term. It also states an O(√n) bound for arbitrary signatures, rank-two and physical-pair determinant estimates, spectral-spread/Fourier bounds, no-pivot reductions, lower-order integrability, hub conditioning and fixed-matrix continuity.

Earlier shared notes include the diagonal π bound; rank-two half-Riesz estimates; rank-three physical-pivot reductions; and diffuse spectral-leverage cases. These should be presented as development history where stronger current theorems supersede them, not summed as independent frontier advances.

### 8.3 Correction memory carries essential mathematical hypotheses

- A cap-one joint density in three dimensions does not itself imply the indefinite density bound. A volume-one thin shell around x²+y²−z²=0 pushes forward to a density1/δ on an interval of widthδ. The shell destroys a proposed coarea lemma, while violating the product-law assumption of the target.
- Rotating independent coordinates destroys independence in general. A density cap for an unconditional projection cannot be inserted as a uniform cap for every conditional projection.
- A physical-coordinate identity involving singular minors required an inequality correction.
- An indefinite spread theorem requires diag|A|, not |diag A|.
- A profile bound for intervals is weaker than a measure domination statement for all Borel sets.
- Uniform |t|^(−3/2) Fourier decay fails for arbitrary bounded rough input densities; phase-comb constructions matter.

These are precisely the types of errors a mathematical scar layer can prevent: lost quantifiers, illicit independence, and a stronger theorem silently replacing a proved weaker statement. They also show why every promoted memory should carry assumptions and a dependency pointer.

Sources: [latest release](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/proofnet24/QFORM-density/interactive/20260923T164118Z-full-proof-paper/README.md), [Gaussian-mixture proof](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/proofnet24/QFORM-density/interactive/20260923T164118Z-full-proof-paper/manuscript/gaussian_mixture.tex), [semidefinite proof](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/proofnet24/QFORM-density/interactive/20260923T164118Z-full-proof-paper/manuscript/semidefinite.tex), [manuscript scope/corrections](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/proofnet24/QFORM-density/interactive/20260923T164118Z-full-proof-paper/manuscript/README.md).

## 9. Janson: a mathematical improvement in the statement, not just a proof patch

For fixed weights w_j≥0,w₀>0 with limsup w_j^(1/j)=∞, allocations of m balls to n boxes have mass proportional to ∏w_(y_i), normalized by Z(m,n). The latest17Sep draft states:

For every ε∈(0,1) and0<α<β<∞, there areδ>0 and supported k_r→∞ such that

sup P(Y_(1)≤(1−ε)m)→0,

where the supremum ranges over admissible integer pairs with (1+3δ)k_r≤m≤(1+5δ)k_r and α≤m/n≤β.

Consequently, for every admissible full path m_n/n→λ∈(0,∞), some subsequence has Y_(1)/m_n→1 in probability and L¹. For sampled indices N_j, the universal conclusion holds precisely when N_(j+1)/N_j→1. The original survey already permits sublinear maxima along selected sparse subsequences.

The key exact insertion keeps the **entire** truncated small-box partition factor Z_u(t,n). Inserting one large box and a supported residual representation gives a falling-factorial inequality, rather than comparing all numerator configurations against a single all-in-one configuration. Under displayed size hypotheses it yields

Z(m,n)≥[n/2^(C+1)]w_k W_r Z_u(t,n).

Record-dependent tilts and a geometric record-margin estimate then create uniform mass windows.

An older claim P(Y_(1)=m)→1 is false: factorial weights yield a nontrivial limit e^(−1/λ). The corrected theorem is about a fraction tending to one, and only along appropriate subsequences. The17Sep manuscript explicitly excludes positive-boundary-mean Problem19.40/preprint18.39. The numbered problem solved in the draft is published19.41/preprint18.40.

The archive reports18,000 sharp-insertion and13,240 coarse-insertion finite checks,3 labelled double counts,84 geometric-tail checks, and23,713 plane trees with422 conditional-root identities. These tests check finite identities and edge cases, not the universal limiting theorem. Five review passes are five sequential same-assistant self-reviews, not five independent referees.

Sources: [manuscript](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/paper_zero_radius_condensation_2026_09_17/main.tex), [README](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/paper_zero_radius_condensation_2026_09_17/README.md), [audit summary](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/paper_zero_radius_condensation_2026_09_17/audits/SUMMARY.md).

## 10. Free Brownian motion and Thévenin: two source-facing candidate contributions

### Free-Brownian unimodality

The source2017/2018 paper proves a sufficient threshold t≥4D² for compact-support diameter D and asks for the optimal constant. The project manuscript claims **t≥D²**, sharp at the symmetric two-point law. The two proof routes use a Cauchy-profile curvature inequality and a Choquet/extreme-two-atom reduction feeding into Biane subordination. A classical-Gaussian companion threshold t≥D²/4 should be described as background unless novelty is independently established.

The source's displayed lower bound2≤C≤4 is inconsistent with its own Bernoulli example: support{−1,1} has D=2 and transition t=4, which yields C≥1 under its normalization. This inconsistency was verified in the actual arXiv HTML, not inferred from an unreliable queue extraction. Do not propagate that factor-of-two error.

The Lean material checks algebraic cores. Analytic subordination, measure-theoretic regularity, and the full theorem are separate obligations; the parent Lean review will state the exact machine-checked boundary.

Source: [project README](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/probability_campaign_2026_09/paper_free_unimodality_2026_09_14/README.md); [primary source](https://arxiv.org/html/1710.08240v2).

### Conditioned Galton–Watson degree counts

The15Sep Thévenin paper constructs two offspring laws: one subcritical with finite third moment and no exponential moment, another critical with infinite variance. The giant degree can fall into two alternatives separated by order√n, creating opposite-mean Gaussian mixture limits for a normalized degree-one count. This refutes a simple Gaussian-law expectation in the specified source regimes.

An earlier critical proof used an insufficient growth schedule; the latest construction requires substantially faster scale separation. The update should control claims. Its exact dynamic-programming checks compare Łukasiewicz and conditioned-multinomial counts at n=256 and asymptotic arithmetic at n=2³². These are supporting finite tests, not independent proof of the asymptotic law.

Source: [latest paper README](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/probability_campaign_2026_09/paper_thevenin_2026_09_15/README.md).

## 11. Exact continuum and graph certificates: what tests actually prove

For Sidorenko's H=K₅,₅ minus C₁₀, the project parametrizes all symmetric nonnegative3×3 matrices with row sum3 by a three-dimensional polytope. The homomorphism polynomial has664 integer monomials and degree≤15. Symmetry reduces its boundary to two face types; a radial factorρ⁴ is extracted because source subgraphs with leaves vanish under zero row sums. Four closed parameter cubes are converted to tensor Bernstein form. Their12,288 exact rational coefficients have positive minima; the least is725117/3179904>1/5. Bernstein basis functions are nonnegative and sum to one, so the coefficient minimum proves a continuum lower bound on each entire cube. This is an actual computer-assisted restricted proof, stronger than a grid search, but unequal block sizes, irregular hosts and general graphons remain uncovered. Novelty is not certified and independent external audits were not performed.

Source: [Sidorenko certificate explanation](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/proofnet24/C30-sidorenko/contributions/2026-09-17_three-block-stability/README.md).

The Aldous–Fill arc-transitive counterexamples use cycle blow-ups C_m[overline K_r], an arc-transitive2r-regular graph. Exact hitting formulas j(m−j)+(r−1)m and twin hitting time rm expose failures in all three literal clauses of OP7.27. The method's value is a transparent obstruction, with rational linear-system checks and algebraic formalization. It is not evidence that every vertex-transitive hitting conjecture is false.

The newer OP4.49(ii) construction cones over fixed-degree bipartite Ramanujan graphs and proves F(G)/(τ_rel(G)D(G)) can grow without bound. This addresses the universal finite-K question; an older numerical ratio≈2.066512 only defeated constant2. Exact weak metric duality and the original flow normalization are essential. The source claims two independent other-track audits, but no exhaustive external literature priority review.

Sources: [arc-transitive paper](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/probability_campaign_2026_09/paper_arc_transitive_2026_09_15/README.md), [Ramanujan-cone closure](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/probability_campaigns/PROB20_replenishment_2026-09-14/PROB20-13/paper_af449_ramanujan_cone_refutation/README.md).

## 12. Ten flagship progress metrics: report the remaining gap

The20Sep operations source tracks the following frontier quantities. These are repository reports, not a verified comparison to all current external records.

| Track | Reported progress | Remaining mathematical obligation |
|---|---|---|
| FEI | Restricted constants, composition/entropy identities and counterexamples | Universal Boolean-cube bound |
| Binary LCS | Upper0.8262759427622826; reference lower0.792665992 | Exact γ₂; material tightening |
| Negative spherical perceptron κ=−1 | Lower6.30297437506, upper12.3196348278; conditional third-lift12.28722223 | Valid comparison theorem and directed four-dimensional root certificate; exact threshold |
| Random3SAT | Candidate upper4.3888762 versus4.38890 | Stronger established scope and exact threshold; not merely numerical1RSB evaluation |
| Integrated fBM H=1/4 | Reported0.171587<θ≤1/4 using covariance/Ritz/Hermite certificate | Exact persistence exponent; earlier H(1−H) formula is not an established target truth |
| Galton–Watson speed | Monotonicity for a displayed mixed{3,4} family and bias range | General no-leaves offspring/bias conjecture |
| Uniform forests | Exact partition-function and graph reductions | Every finite graph |
| Transitive expander cutoff | Gaussian profile in selected Cayley families | Bounded-degree vertex-transitive expander class |
| Cayley percolation | Reported selected degree-seven SL_n(Z) family n≥5, p_c<0.21<0.22<p_u | Every nonamenable Cayley graph/generating set |
| Exponential FPP strict convexity | Direction comparisons, failed-route barriers | A strict defect2μ(e₁)−μ(1,1)>0; current lower bound remains0 |

The progress metrics often remain unchanged in exact audited runs. These null results are part of the evidence base, not an embarrassment to omit. For example, Hadamard0→0, Černý7→7, Hadwiger–Nelson509→509, and the saturated Baum–Connes subgroup2→2 directly refute any blanket assertion that each scheduled research run created new mathematics.

Sources: [compute strategy](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/operations/COMPUTE_STRATEGY_2026-09-20.md), [progress register](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/operations/PROGRESS20_2026-09-20.md).

## 13. Further catalogue reconciliation rules

The campaign index reports many more named results. It is appropriate to inventory them while retaining SOURCE_REPORTED_UNVERIFIED status:

- Janson18.4 largest-box,18.9 bounded-m caveat,18.10 fixed-j total variation,18.30(ii)/(iii) rare-atom counterexamples,18.41/18.42 multi-condensate examples,20.1 width uniform integrability and20.2–20.4 non-Gaussian degree laws. Published/preprint renumbering must be checked individually.
- Janson height20.5/20.7/20.9 incorporates external Addario-Berry–Donderwinkel2024 results. Imported known mathematics is a useful memory asset, not Brain's new solution.
- MMPP scalar c²≥1 is already He2021; a complex order conjecture is a different claim.
- A five-type strictly non-Volterra QSO fixed-point example is already Jamilov2017; broader swaps/indices/segments must be separated if new.
- Sylvester-Hadamard discrepancy counterexamples reuse1983 Reed–Muller covering-radius mathematics; this is not the Hadamard existence conjecture.
- Complex Ginibre average-singular-value monotonicity is reported known from Hutník2026.
- Brownian-sheet and mobile-Boolean questions have narrow dimension/homogeneity scopes.
- A2026 frog-model “factor four” claim still lacks a two-sided criterion; a reduction is not a solved threshold.
- Fresh urn derivative-martingale and Lévy-drift records contain corrected clauses, not universal solutions of every theorem in their parent paper.

The exact raw statements and inherited source IDs for all these and the remaining queue items are in the complete CSV/JSON supplement. A detailed paper can be comprehensive about the available catalogue without pretending to have independently refereed more than a thousand statements.

### Later adjudication corrections relevant to research-status claims

The independent audit agent supplied the round-five W7 ADJUDICATION.json correction: an older card MQ066/claim_a57f98cc falsely inferred that critical nonpercolation plus uniqueness imply a connected minimal spanning forest. The correct implication in that record yields equality of the free and wired minimal spanning forests with one-ended component trees, not a single connected tree. A high-dimensional lattice reductio shows the gap; Lyons–Peres Question11.35 remains open in that adjudication. Likewise, an older gossip-game key saying all n≤7 was stale after a component-sum identity failed. The corrected unrestricted proved scope in that record is n=4 for all k and k=2 through n≤5; further entries are only the displayed machine-verified finite table. These later corrections should override older unqualified “solved” cards. Source: [W7 adjudication](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/brain_improvement/campaign_2026-09-22_opus55_round5/w7_math_test/grade/ADJUDICATION.json), blob19154f64b8abd335d0f0f6856e7713f7fe89118a. This paragraph is a cross-agent readout, not my independent rederivation.

## 14. Earlier broad research: mathematical value and unresolved bridges

The broad archive's solved register reports Gaussian real phase-retrieval exponent ω(A)=4^(−m+o_P(m)) for a(2m−1)×m matrix, real/complex minimum-square-submatrix exponents −β⁻¹log[γ^γ/(γ−1)^(γ−1)], fixed-apex overlap identity E(1/D)=N/[m(N−m+1)], and a sharp Gr(2,n) Plücker-star ratio α_n/(1−α_n) with α_n=(2/n)sin²(π/n). These are archived project claims with accompanying exact and analytic reductions; they are not automatically demonstrated Math Brain-assisted output.

The archive explicitly keeps non-Gaussian anti-alignment/angular-pair bridges and conditional overlap kernels open. First two factorial moments do not prove a full Poisson limit. A deterministic full-spark upper bound proportional to1/√m is qualitative/polynomial and must not be called an exponential Balan–Wang result.

Source: [broad solved register](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/06_math_research/Open%20problem%20project/solved_register.md).

## 15. What this evidence justifies about usefulness

The mathematics gives several defensible kinds of utility:

1. **Hypothesis preservation:** retain independence, sign, centering, rank, support and uniformity assumptions beside every formula.
2. **Counterexample reuse:** retrieve a small obstruction before a worker invests in a known-false generalization.
3. **Dependency accountability:** show which unproved bridge prevents a restricted theorem becoming a source-level solution.
4. **Exact certificate reuse:** promote an algebraic identity or rational coefficient certificate with reproducible scope.
5. **Novelty control:** identify a known external theorem or a saturated fixed target and stop false credit.
6. **Continuity across long research:** make corrected state and proof obligations available when the active context is rebuilt.

The direct G0013 trace illustrates one promotion changing a local sign check. The richer campaigns demonstrate the information that should be preserved and supplied. A controlled experiment is still required to estimate how much these mechanisms improve theorem-solving success, proof correctness, time or token cost. The present catalogue supplies research cases and failure modes suitable for that experiment; it does not substitute for it.
