# Lean integration, proof audits, and a formal model of pseudo-cognitive dynamics

Prepared 23 September 2026. This is source-grounded research support for the requested Math Brain paper. No repository was mutated. The Python controls described below were executed locally; the historic Lean compilations were inspected through committed source and logs and were not rerun here.

## 1. Main conclusions for the paper

There are three distinct objects that must remain distinct throughout the manuscript: (i) the broad cognitive system, whose proof-audit hooks and Mathlib checker are deployed through a local Claude/Windows environment; (ii) the isolated `private-source-repository` package, with a substantial but stricter proof-authority implementation; and (iii) research-specific Lean files committed to `math-open-problems` and the broad research archive. Evidence about one object does not certify the operation or mathematical completeness of the others.

The research archive contains useful Lean verification of algebraic and analytic cores. In three representative paper companions, committed logs report 47 distinct named declarations in total: 13 for free unimodality, 17 for arc-transitive graph arithmetic, and 17 for conditioned Galton–Watson degree-count arithmetic. These are **47 entries in inspected axiom reports**, not 47 open problems solved and not a complete machine formalization of the three papers. The log dependencies are subsets of the conventional Lean axioms `propext`, `Classical.choice`, and `Quot.sound`.

The isolated package's own formal library has only three natural-number control declarations at the inspected snapshot. Its large Python authority system is therefore evidence of verification engineering, not a large corpus of formally proved research theorems. Moreover, inspected scheduled-run records dated 21 September explicitly report missing Lean/package dependencies and zero of three genuine formal controls completed. Passing sandbox and parser tests must not be reported as successful Lean theorem checks.

“Conscious” and “subconscious” should be introduced as **operational vocabulary**: the model's currently supplied context is the conscious layer, while persistent records, associations, retrieval, and background consolidation form the subconscious layer. No claim about subjective experience follows from this naming. “Mathematics of Pseudo-Cognitive Dynamics” can name the proposed research programme; the elementary propositions below are a precise formulation and useful design consequences, without establishing a historically new mathematical theory or empirical superiority.

## 2. Source snapshots and principal files

| Repository | Pinned commit used |
|---|---|
| `private-source-repository` | `a4c99b43a044c127787c26997ed942f41591aac6` |
| `<private-repo>` | `bcff9346b68959f4cf330fdf9ca0e64a21c77d3e` |
| `yspennstate/math-open-problems` | `b4745ece98fa3839cf7afe35d829d08384c815b4` |

Selected blob identities:

| File | Git blob SHA |
|---|---|
| math brain `src/math_brain/lean.py` | `bfb9dc834c43d209c23e2fbcfeaec245a2adf711` |
| math brain `src/math_brain/verification.py` | `5fb626aa07bc4eff289bd3db125ff3b36df57fd1` |
| math brain `src/math_brain/proofswarm.py` | `02622dfb0146b18ec89c0f3b2fdbdf3a14c3f35b` |
| math brain `tests/test_lean.py` | `c4e2ba322c86d743df3c4ebaa803225f2b186a7a` |
| math brain `docs/formal-verification.md` | `3bbdd7574338bd83ed783fc87abe45a7897ef789` |
| math brain `formal/MathBrain/Basic.lean` | `80e474c4dec7155d45aab31e9c4343a00fb8cfba` |
| broad brain `12_cognitive_architecture/dreaming/proof_sense.py` | `c778aa107b8e0e8a8da5ec915239e2f036d1f1ff` |
| broad brain `12_cognitive_architecture/dreaming/proof_receipt.py` | `da36e1504785fdc0672eca6eef04a31cd64e7399` |
| broad brain `12_cognitive_architecture/dreaming/lean_check.py` | `d62e208b1a6dbb50174d0980e857f5be9174ba56` |
| broad brain `12_cognitive_architecture/dreaming/lean_process.py` | `64bbe24ac22e78e30526348e35a2600aa4a25e5f` |
| broad brain `12_cognitive_architecture/dreaming/proof_deny_hook.py` | `984ab2239febf7c955c4a3088dbc345055656bb4` |

Full fetched text is available beneath `/workspace/scratch/dcdc9cb9de1d/lean_sources/`. The filename hierarchy preserves repository paths. Repository identity must be recovered from this table because files from the three repositories share that evidence directory.

## 3. What the isolated Lean authority actually implements

The formal project pins `leanprover/lean4:v4.30.0`. `check_lean_file` stable-reads the project and copies accepted source bytes into a private snapshot. It accepts a strict dependency-free `lakefile.toml` schema but does not launch Lake or its package resolver. Local module imports are compiled in dependency order using a fixed direct Lean invocation, including `--trust=0`, one worker, and a memory bound. The source policy rejects proof placeholders, newly declared axioms, nonlocal imports, native evaluation, custom elaborators, and output-producing escape mechanisms. This intentionally narrow surface differs from the Mathlib projects used for the research companions. [Formal-verification design](https://github.com/private-source-repository/blob/a4c99b43a044c127787c26997ed942f41591aac6/docs/formal-verification.md), [implementation](https://github.com/private-source-repository/blob/a4c99b43a044c127787c26997ed942f41591aac6/src/math_brain/lean.py).

A successful compilation is diagnostic unless at least one exact declaration is named. Each declaration must have one canonical source-side `#print axioms` command and one output reporting no axioms. This policy is stricter than ordinary Mathlib practice: **it requires an empty reported axiom set**, rather than accepting the three conventional axioms. An execution envelope binds source hashes, declaration names, toolchain and executable identity, environment, output, compute admission, resource limits, process containment, and cleanup. An ephemeral in-process HMAC prevents post-execution substitution before evidence issuance. HMAC authenticity means the fields are bound to an issuance path; it does not itself establish mathematical truth or trustworthy human judgment. [Implementation](https://github.com/private-source-repository/blob/a4c99b43a044c127787c26997ed942f41591aac6/src/math_brain/lean.py).

`LocalLeanEvidenceAuthority.verify_and_issue` emits a kernel-evidence record, automated attestation, and receipt only if all authority-eligibility predicates pass. `LocalFormalizationFidelityAuthority` is a separate role using distinct key material. Its seven required review dimensions are quantifiers, domains, definitions, assumptions, conclusion, boundary cases, and absence of extra axioms. It binds the hashed prose claim to exact formal source spans and the sealed kernel result. These are **software requirements for a human-review record**, not proof that a particular human performed a high-quality review in every historical run. The trusted reviewer remains part of the assurance argument. [Implementation](https://github.com/private-source-repository/blob/a4c99b43a044c127787c26997ed942f41591aac6/src/math_brain/lean.py).

The status policy permits two alternative verification routes for theorem/lemma records: kernel evidence plus formalization fidelity, or human proof review plus independent reproduction. Computation records require numerical or symbolic evidence plus independent reproduction. A verified counterexample prevents positive promotion; heuristics cannot become verified theorems; a conjecture must first be restated as a theorem. Imported ProofSwarm tickets remain discovery records even if their external label says `lean_verified` or `disproven`. Thus retrieval confidence, peer labels, and claim status are deliberately separate variables. [Promotion policy](https://github.com/private-source-repository/blob/a4c99b43a044c127787c26997ed942f41591aac6/src/math_brain/verification.py), [ProofSwarm importer](https://github.com/private-source-repository/blob/a4c99b43a044c127787c26997ed942f41591aac6/src/math_brain/proofswarm.py).

### 3.1 Runtime limitations evidenced by actual records

The package's POSIX executable lease explicitly sets `executable_lock_enforced=False`. Since eligibility requires this flag to be true, a successful POSIX compilation on this production snapshot is insufficient for authoritative issuance. Proposed descriptor-lock and isolation adapters occur in worker-owned work areas; their presence does not show they were integrated into the production authority path.

| Inspected historical record | Reported result | What it establishes |
|---|---|---|
| account01/B14, 21 Sep 09:11, `native_attempts.json` | Lean/Lake/Elan absent; package imports fail; genuine fixtures `0/3` | This run did not execute the production Lean controls |
| same run, `runtime_jail_result_v1.json` | synthetic jail PASS; `kernel_checked=false`, `formal_authority_eligible=false` | Filesystem/network containment experiment only |
| account03/B14, 21 Sep 07:38, dependency probe | no normal math package or Lean; kernel `0/2`, admitted-source gate `0/1` | Distinct package, binary transport, compute-state, and POSIX locking blockers |
| account04/B14, 21 Sep 08:11, acceptance record | genuine formal controls `0/3`; no local Lean/package; interpreter probe `5/5` | ELF interpreter coverage tests passed; no kernel or prose-fidelity evidence |

These observations are dated records, not a claim about all current machines or all historical runs. They nevertheless prevent describing the scheduled Linux fleet as an already demonstrated end-to-end Lean verification system.

Record citations: [account01 native attempt](https://github.com/private-source-repository/blob/a4c99b43a044c127787c26997ed942f41591aac6/scheduled_tasks/runs/account01/B14/20260921T091134Z-b14-formal-r11/native_attempts.json), [account01 synthetic jail](https://github.com/private-source-repository/blob/a4c99b43a044c127787c26997ed942f41591aac6/scheduled_tasks/runs/account01/B14/20260921T091134Z-b14-formal-r11/runtime_jail_result_v1.json), [account03 dependency probe](https://github.com/private-source-repository/blob/a4c99b43a044c127787c26997ed942f41591aac6/scheduled_tasks/work/account03/B14/20260921T073858Z-b14-r11-22eae6/formal_backend_dependency_probe.json), [account04 acceptance](https://github.com/private-source-repository/blob/a4c99b43a044c127787c26997ed942f41591aac6/scheduled_tasks/runs/account04/B14/B14-20260921T081150Z-r11/formal_backend_acceptance.json).

## 4. The broad brain's actual proof-audit interface

`proof_sense.py` supplies a specialized `UserPromptSubmit` lane. It detects mathematical arguments, scores six classes of cues, selects at most three, retrieves short theorem-applicability notes, and constructs a step inventory. The cue classes cover named-theorem hypotheses/direction/rate, inequality directions, paired operators and quantifiers, index/constant arithmetic, load-bearing hypotheses, and limit targets. Counts are weighted: named-result cues receive weight 6, limit cues 2, and paired operators 1.5; other classes receive weight 1. A per-session ten-minute interval bounds repeated injections. Truncated step inventories explicitly declare the omission. [Proof-sense source](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/proof_sense.py).

This is a concrete example of the requested subconscious-to-conscious mechanism: stored classes of previous mathematical failure become a small task-specific context packet before the model audits an argument. The packet identifies what to inspect; it does not certify an answer. The code specifically warns that an unsuccessful tactic, missing import, syntax error, timeout, or resource hold does not refute a theorem. It also warns that a retrieved mathematical note is itself a claim whose applicability must be checked. These distinctions should be prominent in the paper.

The same source documents a consequential earlier failure: general high-charge scars occupied scarce retrieval slots on proof tasks and encouraged treating proof steps as instructions; in its described probability-bank comparison, the brain arm accepted flawed proofs more often than the sterile arm. The separate audit lane was introduced to correct this routing mismatch. This source comment identifies the mechanism and reported motivation; the benchmark specialist should supply the corresponding raw run counts before it appears as a quantitative result. A later September 22 correction suppresses “weaker hypothesis” alarms when the supposedly weaker property is what the theorem is legitimately proving. The comments report three false alarms in three firings on a harder-35 bank. This is evidence that negative-memory cues can overgeneralize and need evaluation, not universal guarantees from the presence of scars.

The broad `lean_check.py` uses an existing local Mathlib project and a pinned Lean 4.29.1 executable path. It has a Windows-only process owner with a suspended child assigned to a native Job Object before launch, background priority, timeout, and resource admission. Its receipt parser checks the exact structural Lean name, theorem declaration kind, and axiom-name constructor trees. It permits only the three conventional Lean axioms and rejects `sorryAx` and custom axioms. The source's explicit review-hash argument records a **caller assertion**; the checker is not a sandbox and does not independently verify dependency bytes. Its output preserves `translation_fidelity=UNVERIFIED`. These properties differ materially from the strict isolated package. [Checker](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/lean_check.py), [receipt parser](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/proof_receipt.py), [process owner](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/lean_process.py).

`proof_deny_hook.py` is a different mechanism: a `PreToolUse` Bash guard for narrowly recognized command failures. It operates in shadow mode unless enabled, has a three-per-session cap, reserves persistent budget before blocking, and allows execution on errors. It is not a theorem prover. Its two described predicates concern Bash-mangled Windows paths and Python heredocs that fail parsing; a hook's operational veto must not be confused with a mathematical proof verdict. [Guard source](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/dreaming/proof_deny_hook.py).

## 5. Research Lean evidence and its exact scope

| Research companion | Formal content inspected | Axiom-log count | Scope limitation |
|---|---|---:|---|
| Free Brownian unimodality | rational identities, polynomial inequalities, equality case, Cauchy profile bound, symmetric Bernoulli profile, classical threshold algebra | 13 named declarations | Does not formalize arbitrary probability measures, free convolution, Biane's parametrization, or the complete main theorem |
| Arc-transitive blow-up graphs | harmonic polynomial identity, twin/neighbour values, cycle sums, hitting-mass formulas, quadratic bounds and ratio arithmetic | 17 named declarations across two files | Definitions such as `g` are arithmetic formulas; their identification with stochastic hitting times and the graph-theoretic scope remain in prose |
| Conditioned Galton–Watson degree counts | recursive stage arithmetic, rare-mass bounds, atom-exclusion inequalities, centering, Bernstein exponent, characteristic-function zero, critical-law base/update identities | 17 named declarations | Does not formalize the complete conditional limit theorem, every probability estimate, or the full counterexample argument |
| Bernoulli convolution at two-thirds | archived conditional contraction/summability and analytic/algebraic lemmas; seven-file recheck lists 25 declarations | 25 in a separate summary record | README explicitly says one-copy absolute continuity is not proved; filenames such as `BC23Full` do not change this |

For free unimodality, the inspected file is at the companion directory root, although its README describes a `lean/` subdirectory. Its blob is `409c16ca3e3cdf83cc828584611b81c847126846`; `build3.log` is `68808836f0e923467abd3fb14f47dbe96ffba3d6`, reports the 13 axiom inventories and `exit=0`. [Source](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/probability_campaign_2026_09/paper_free_unimodality_2026_09_14/FreeUnimodality.lean), [log](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/probability_campaign_2026_09/paper_free_unimodality_2026_09_14/build3.log).

The arc-transitive log reports Lean 4.33.1 with Mathlib commit `0df444a360eaa60ab8c11dca51a86af692955474`, successful GitHub Actions compilation, and nine `P0208` plus eight `BlowUp` axiom inventories. Duplicate printed output is deduplicated here. `BlowUpArithmetic.lean` contains additional arithmetic lemmas whose names are not printed in this selected inventory, so 17 is not a claim about every declaration compiled. [Arithmetic source](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/probability_campaign_2026_09/paper_arc_transitive_2026_09_15/BlowUpArithmetic.lean), [log](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/probability_campaign_2026_09/paper_arc_transitive_2026_09_15/build_and_axioms.log).

The degree-count log records a 42-second build job, conventional axiom subsets, and 17 named declarations. Its source is blob `27301a8bf93230a5971db0088451dae988769dd3`; the log is `7b085a6ff11140466dc19fe0727dbb70893801bd`. [Source](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/probability_campaign_2026_09/paper_thevenin_2026_09_15/DegreeCounts.lean), [log](https://github.com/yspennstate/math-open-problems/blob/b4745ece98fa3839cf7afe35d829d08384c815b4/probability_campaign_2026_09/paper_thevenin_2026_09_15/build_and_axioms.log).

The Bernoulli archive reports seven rechecked files with theorem counts 2, 1, 2, 4, 4, 7, and 5, totaling 25, and zero `sorryAx` occurrences in that summary. Its separate README expressly retains an open contraction/coarse-law gap and labels a five-agent fan-out's dead-end findings as not adversarially verified. [README](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/audits/bc23_20h_20260906/lean/README.md), [recheck summary](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/audits/bc23_20h_20260906/lean/FULL_RECHECK_20260908.txt).

### 5.1 Why the axiom inventory is necessary but insufficient

Lean checks a formal statement against definitions and dependencies. An axiom inventory detects admitted dependencies such as `sorryAx`, while ordinary Mathlib proofs can legitimately use `propext`, `Classical.choice`, and `Quot.sound`. It does not establish that the formal statement is the intended informal theorem. In particular, a theorem with an unproved mathematical hypothesis as an explicit parameter can be perfectly checked without listing that hypothesis as an axiom. Statement, quantifier, and hypothesis audits are therefore indispensable. The official manual also distinguishes routine checking from stronger independent rechecking and theorem-statement comparison. [Lean proof-validation manual](https://lean-lang.org/doc/reference/latest/ValidatingProofs/), [Lean axioms reference](https://lean-lang.org/doc/reference/latest/Axioms/).

## 6. Fresh verification performed for this report

The existing `proof_sense._selftest()` passed its one positive mathematical-argument trigger and two negative controls. External deployed knowledge loading was disabled for this isolated test, so this checks the source's trigger/render behavior, not real memory retrieval.

Eleven direct parser controls against the actual `proof_receipt.classify` function passed: conventional axioms, no named target, unreviewed source, mismatched review hash, compilation failure, timeout, evidence drift, duplicate identity output, non-theorem declaration, `sorryAx`, and a custom axiom. Every result retained `translation_fidelity=UNVERIFIED`, including the synthetic accepted formal target. No Lean compiler ran; the input messages were synthetic parser fixtures. This is narrow regression evidence, not an eleven-theorem result or a model-performance benchmark.

Machine-readable report: `/workspace/scratch/dcdc9cb9de1d/lean_parser_controls_20260923.json`. The root author may include this as an appendix or supporting artifact.

## 7. Proposed mathematical formulation

This section is **a new exposition for the requested paper**, not a claim that every operator below is implemented, and not an assertion of scientific priority. Let the state at event time t be

\[
S_t=(C_t,M_t,W_t,G_t,L_t),\qquad \ell(C_t)\le B.
\]

Here C_t is the finite working context; M_t is persistent memory; W_t is an associative-weight graph; G_t is the claim/evidence/dependency graph; L_t is an append-only event and cost ledger. Memory records can carry episode, fact, method, mistake, scar, open-gap, source, or control roles. These roles are data types, not neural organs. A record includes content, applicability conditions, origin, timestamp, source identity, and evidence state.

An event e_t (user task, tool result, repeated failure, checkpoint, or scheduled review) activates a hook H. The hook produces a query q_t and a retrieval budget b_t. A retrieval policy selects a finite set R_t from M_t, a packing policy injects it into context, and the model produces an action:

\[
q_t=H(e_t,C_t),\quad R_t=\mathcal R(q_t,M_t,W_t,G_t;b_t),\quad
\widetilde C_t=\operatorname{Pack}_B(C_t,R_t),\quad
a_t\sim\pi_\theta(\cdot\mid\widetilde C_t).
\]

The action's observed result y_t is assessed by a verifier V and recorded by an update rule U:

\[
(M_{t+1},W_{t+1},G_{t+1},L_{t+1})=U(S_t,e_t,R_t,a_t,y_t,V(y_t)).
\]

The parameter vector theta is fixed in this external-memory model. Learning consists of changing retrieval records, graph weights, procedural rules, and evidence states; it need not modify the language model's weights. The conscious-layer name applies to the material actually supplied to the model at inference time. The subconscious-layer name applies to stored material and external operations that can influence what is supplied later. The distinction is about access and control, not phenomenology.

### Proposition 1: budget preservation

Suppose Pack_B preserves mandatory material P_t, reserves token space o_t for the response, and accepts retrieved material only when its exact serialized token length fits the remaining budget. If ell(P_t)+o_t <= B, then ell(tilde C_t)+o_t <= B at every event.

**Proof.** At each packing step, the accepted serialization is checked against B-o_t. Thus each accepted state satisfies the inequality. Induction over accepted blocks gives the result; rejected blocks do not change it. If mandatory material already exceeds capacity, the premise fails and a policy must explicitly compress, split, or stop. The proposition does not establish that useful information was retained. **End proof.**

### Proposition 2: bounded, saturating salience

For normalized contributions 0 <= c_j <= 1, consider the noisy-OR score

\[
F(c)=1-\prod_{j=1}^{m}(1-c_j).
\]

Then 0 <= F <= 1, F is coordinatewise nondecreasing, and the marginal increase from adding a contribution c is c times the existing residual product. Thus extra cues have diminishing marginal effects as other cues increase.

**Proof.** Each factor lies in [0,1], proving the bounds. Differentiating gives partial_j F = product_{i neq j}(1-c_i) >= 0. Alternatively, directly appending a new contribution gives F(c_1,...,c_m,c)-F(c_1,...,c_m)=c product_{i=1}^m(1-c_i). This product cannot increase when an existing contribution increases. **End proof.**

For the repository's age-weighted form, multiply the residual by 1-exp(-age/1.3), then multiply F by 100. The same boundedness and monotonicity hold under normalized contributions. The probability-of-a-union interpretation requires independent underlying events; algebraic use as a salience score does not establish that independence, truth, or calibration. This is a property of the formula supplied by the architecture investigator, not a newly validated brain-performance law.

### Proposition 3: stable coactivation with forgetting

Consider an idealized edge update w_{t+1}=rho w_t+eta_t, where 0 <= rho < 1, w_0 >= 0, and 0 <= eta_t <= eta_max. Then

\[
w_t=\rho^t w_0+\sum_{j=0}^{t-1}\rho^{t-1-j}\eta_j
\le\rho^t w_0+\eta_{\max}\frac{1-\rho^t}{1-\rho}.
\]

**Proof.** Repeated substitution proves the equality by induction. Bound every eta_j by eta_max and sum the finite geometric series. **End proof.**

With rho=.98 and eta_max=1, the upper limiting bound is 50. If reinforcement ceases, the weight decays geometrically; pruning at a strictly positive threshold epsilon then removes it after a finite number of update events. Here t counts update events, not necessarily wall-clock time. Clipping and pruning can only lower this particular bound. This models a bounded-input version of the architecture's reported .98-decay coactivation rule. A production fold can aggregate reinforcement from multiple sessions; without a verified per-fold bound of one, 50 is not a bound on production weights. The general formula applies with the actual eta_max if such a bound exists.

### Proposition 4: compositional provenance

Let G be a finite acyclic graph of formal claims. For each node v, suppose a trusted checker verifies a proof of P_v from its parent propositions and an explicitly recorded assumption set A_v. Then P_v follows from the union of A_u over all ancestors u of v, including v. Consequently, an unconditional claim cannot be obtained merely by erasing an unresolved dependency from a display.

**Proof.** Topologically order the graph. A leaf follows from its own A_v by hypothesis. For an internal node, substitute the already established proofs of its parents into its checked implication from those parents to P_v. Its assumptions are contained in A_v union the accumulated parent assumptions. Induction proves the stated ancestor union. **End proof.**

This is a standard logical composition principle, included to specify an auditable system invariant. It assumes trustworthy proof checking and exact statement matching. It does not authenticate its own source, certify prose-to-formal equivalence, or turn a numerical experiment into a theorem. A source hash identifies bytes; mathematical validity needs additional evidence.

### Proposition 5: sound scoped scars prevent exact repeated failures

Suppose every failure signature sigma includes the task-relevant assumptions and environment version. A scar consists of a verified predicate D_sigma(a,C) that implies failure under those assumptions. Assume additionally that every later attempt in the targeted signature class satisfies D_sigma, retrieves that scar, and is mandatorily vetoed before execution. Assume the first executed failure in a class creates its scar before the next attempt in that class. Then after the first recorded failure with sigma, no further failure in that class is executed. For a closed universe of K such signature classes, at most K failures in those classes are executed.

**Proof.** On any later occurrence, coverage guarantees that the predicate is true, retrieval supplies it, and the mandatory pre-execution gate excludes the attempt. Thus a second executed occurrence contradicts the hypotheses. There can be at most one executed first occurrence in each of K classes, proving the bound. This does not imply every class is eventually visited or every scar is eventually populated. **End proof.**

This proposition is intentionally conditional: incomplete retrieval, vague signatures, changed hypotheses, invalid scars, and a model ignoring a soft warning invalidate its assumptions. A broader warning can suppress a valid new proof route; the system therefore needs negative controls, explicit scope, and scar invalidation. The repository's specialized proof-audit lane and weaker-hypothesis correction illustrate why this matters.

### Proposition 6: token amortization and cost per accepted solution

Let T_build be a consistently measured construction-token budget. On deployment task i, let D_i be the baseline cost for achieving a fixed accepted quality criterion, S_i the cost saved by useful memory, and R_i the additional retrieval, injection, consolidation, and verification cost. Then the memory system has lower cumulative token cost exactly when

\[
\sum_{i=1}^{n}(S_i-R_i)>T_{\mathrm{build}}.
\]

**Proof.** Baseline cumulative cost is sum D_i. Memory cumulative cost is T_build + sum(D_i-S_i+R_i). Subtract and rearrange. **End proof.**

If expected net saving is a stationary positive delta, the expected break-even condition is n delta > T_build. This does not estimate delta. With unequal solution rates, also report cost per accepted result: for a specified iid attempt distribution with expected tokens c and success probability p>0, the long-run ratio of total tokens to successes tends to c/p under the usual law-of-large-numbers conditions. Therefore, a memory arm with larger per-attempt token use can be efficient if its accepted-solution rate improves sufficiently; a cheaper but less reliable arm can be inefficient. No construction total or operating saving can be inferred from repository byte size or commit count.

### A necessary non-guarantee

More memory does not mathematically imply better answers. Let the baseline always return a correct answer to one task. Define a retrieval-conditioned policy that follows an incorrect retrieved statement whenever one is present. Its success rate drops from one to zero. Hence no universal monotonic improvement theorem holds without assumptions about selection, applicability, and the model's response to evidence. The useful empirical question is whether this particular retrieval and audit design improves specified outcomes on unseen, controlled tasks at matched resource budgets.

## 8. Primary literature and what each source supports

1. Patrick Lewis et al. (2020), *Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks*, NeurIPS 2020; arXiv:2005.11401. Supports the distinction between parameter-based knowledge and externally retrieved nonparametric memory, and retrieval-conditioned generation. It does not validate this Math Brain implementation. [Paper](https://arxiv.org/abs/2005.11401).

2. Noah Shinn, Federico Cassano, Edward Berman, Ashwin Gopinath, Karthik Narasimhan, Shunyu Yao (2023), *Reflexion: Language Agents with Verbal Reinforcement Learning*, NeurIPS 2023; arXiv:2303.11366. Supports storing linguistic feedback in episodic memory without updating model weights. It is relevant to mistake records and corrective reflection. [Paper](https://arxiv.org/abs/2303.11366).

3. Charles Packer, Sarah Wooders, Kevin Lin, Vivian Fang, Shishir G. Patil, Ion Stoica, Joseph E. Gonzalez (2023), *MemGPT: Towards LLMs as Operating Systems*, arXiv:2310.08560. Supports finite working context with managed memory tiers and interrupt-style control. [Paper](https://arxiv.org/abs/2310.08560).

4. Kaiyu Yang, Aidan M. Swope, Alex Gu, Rahul Chalamala, Peiyang Song, Shixing Yu, Saad Godil, Ryan Prenger, Anima Anandkumar (2023), *LeanDojo: Theorem Proving with Retrieval-Augmented Language Models*, NeurIPS Datasets and Benchmarks 2023; arXiv:2306.15626. Supports premise retrieval, programmatic interaction with Lean, and a benchmark separating novel premises. The Math Brain files inspected here do **not** establish that LeanDojo or ReProver is installed or used. Cite as related work, not as a system dependency. [Paper](https://arxiv.org/abs/2306.15626).

5. Nelson F. Liu, Kevin Lin, John Hewitt, Ashwin Paranjape, Michele Bevilacqua, Fabio Petroni, Percy Liang (2024; preprint 2023), *Lost in the Middle: How Language Models Use Long Contexts*, Transactions of the ACL 12:157–173; arXiv:2307.03172. Supports evaluating the position and selection of context, rather than equating larger context with reliably used knowledge. Its results concern its studied models and tasks. [Published paper](https://aclanthology.org/2024.tacl-1.9/).

6. Murray Shanahan and Bernard Baars (2005), *Applying global workspace theory to the frame problem*, Cognition 98(2):157–176, DOI 10.1016/j.cognition.2004.11.007. Supports the computational analogy of specialist processes exchanging selected information through a shared workspace. This analogy does not make a language-model context a biological workspace or demonstrate consciousness. [Author-hosted paper](https://www.doc.ic.ac.uk/~mpsha/ShanahanBaarsCog05.pdf).

7. Stanislas Dehaene, Jean-Pierre Changeux, Lionel Naccache, Jérôme Sackur, Claire Sergent (2006), *Conscious, preconscious, and subliminal processing: a testable taxonomy*, Trends in Cognitive Sciences 10(5):204–211, DOI 10.1016/j.tics.2006.03.007. Relevant for historically distinguishing access states, with explicit limits on transfer from neuroscience to software. [Primary bibliographic record and abstract](https://pubmed.ncbi.nlm.nih.gov/16603406/).

8. Lean Language Reference, *Validating a Lean Proof* and *Axioms*, accessed 23 September 2026. Supports proof-target identity, axiom inventories, and the distinction between formal acceptance and intended semantics. The live manual discusses versions later than the repository's pinned toolchains; version-specific recommendations must be matched to the relevant runtime. [Validation](https://lean-lang.org/doc/reference/latest/ValidatingProofs/), [Axioms](https://lean-lang.org/doc/reference/latest/Axioms/).

## 9. Recommended language for the research paper

Use: “The system stores reusable methods, failed approaches, source references, and verification records outside the model's active context, then selects task-relevant material for subsequent inference. We call the resulting exchange pseudo-cognitive dynamics. These terms describe software access and control and do not attribute conscious experience to the model.”

Use: “Lean-checked auxiliary results provide evidence about exact formal statements. The research campaigns additionally rely on informal mathematics, literature interpretation, numerical tests, and statement-fidelity review. The presence of checked auxiliary results does not establish that every claimed main theorem has been fully formalized.”

Avoid: “The subconscious solved the open problems”; “all 80 workers had a functioning Lean brain”; “zero axiom proofs” for the Mathlib companions; “the 11/11 test proves the system's mathematical accuracy”; “a new branch of mathematics has been established”; or citing Brain-assisted completion as causal proof of a Brain advantage without a controlled comparison.
