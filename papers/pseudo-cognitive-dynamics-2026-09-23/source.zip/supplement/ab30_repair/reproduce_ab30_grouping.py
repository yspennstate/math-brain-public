"""Portable, synthetic-only regression for the AB30 one-line score repair.

Run with Python 3 from any working directory. Every input fixture and output
RESULT.json exists only in a TemporaryDirectory. No solver, network, native
campaign directory, held-out answer key, or real participant result is accessed.
"""

import contextlib
import hashlib
import importlib.util
import io
import json
import sys
import tempfile
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
EXPECTED_BLOB = "0a1879f693f1512df9142db4bb483dc9d5949468"


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


def write_jsonl(path, rows):
    path.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")


def main():
    original_raw = (HERE / "analyze.py").read_bytes()
    original_blob = hashlib.sha1(
        b"blob " + str(len(original_raw)).encode("ascii") + b"\0" + original_raw
    ).hexdigest()
    assert original_blob == EXPECTED_BLOB, "Original source bytes drifted"
    old = b'for fam in sorted({r["family"] for r in res["items"]}) | {"all"}:'
    new = b'for fam in sorted({r["family"] for r in res["items"]} | {"all"}):'
    assert original_raw.count(old) == 1
    assert (HERE / "analyze_corrected.py").read_bytes() == original_raw.replace(old, new)
    print("SOURCE_IDENTITY_PASS:", original_blob, "; corrected changes only the grouping line")

    with tempfile.TemporaryDirectory(prefix="ab30-synthetic-") as tmp:
        root = Path(tmp)
        grades = root / "synthetic_grades.jsonl"
        mapping = root / "synthetic_map.json"
        metadata = root / "synthetic_family_metadata.jsonl"
        # Family metadata deliberately contains no problem text or answer.
        fixtures = [
            ("synthetic_01", "synthetic_alpha", "full", "zero"),
            ("synthetic_02", "synthetic_alpha", "zero", "half"),
            ("synthetic_03", "synthetic_beta", "half", "half"),
        ]
        grade_rows, arm_map, meta_rows = [], {}, []
        for item, family, on_grade, off_grade in fixtures:
            meta_rows.append({"id": item, "family": family})
            for arm, grade in (("on", on_grade), ("off", off_grade)):
                mid = "synthetic_m%03d" % len(grade_rows)
                grade_rows.append({"mid": mid, "grade": grade})
                arm_map[mid] = {"id": item, "arm": arm}
        write_jsonl(grades, grade_rows)
        mapping.write_text(json.dumps(arm_map), encoding="utf-8")
        write_jsonl(metadata, meta_rows)

        original = module(HERE / "analyze.py", "ab30_original")
        original.RUNS = root
        try:
            original.score(grades, mapping, metadata)
        except TypeError as exc:
            assert "list" in str(exc) and "set" in str(exc), str(exc)
            print("ORIGINAL_FAILED_AS_EXPECTED:", type(exc).__name__, str(exc))
        else:
            raise AssertionError("Original unexpectedly passed")
        assert not (root / "RESULT.json").exists(), "Original unexpectedly wrote results"

        corrected = module(HERE / "analyze_corrected.py", "ab30_corrected")
        corrected.RUNS = root
        with contextlib.redirect_stdout(io.StringIO()):
            corrected.score(grades, mapping, metadata)
        result = json.loads((root / "RESULT.json").read_text(encoding="utf-8"))
        assert len(result["items"]) == 3
        expected = {
            "all": {"n": 3, "on_points": 1.5, "off_points": 1.0,
                    "brain_better": 1, "brain_worse": 1, "sign_test_p": 1.0},
            "synthetic_alpha": {"n": 2, "on_points": 1.0, "off_points": 0.5,
                    "brain_better": 1, "brain_worse": 1, "sign_test_p": 1.0},
            "synthetic_beta": {"n": 1, "on_points": 0.5, "off_points": 0.5,
                    "brain_better": 0, "brain_worse": 0, "sign_test_p": 1.0},
        }
        assert result["by_family"] == expected, result
        print("FIXED_FAMILY_AND_ALL_PASS:", json.dumps(expected, sort_keys=True))

        model_record = {
            "usage": {"output_tokens": 9999},
            "modelUsage": {
                "synthetic_model_a": {
                    "inputTokens": 2, "cacheReadInputTokens": 10,
                    "cacheCreationInputTokens": 3, "outputTokens": 4,
                    "thinkingTokens": 1,
                },
                "synthetic_model_b": {
                    "inputTokens": 5, "cacheReadInputTokens": 20,
                    "cacheCreationInputTokens": 7, "outputTokens": 8,
                    "thinkingTokens": 2,
                },
            },
        }
        counted = corrected.tok(model_record)
        assert counted == {"input": 7, "cache_read": 30, "cache_write": 10,
                           "output": 12, "thinking": 3}, counted
        assert original.tok(model_record) == counted, "Token behavior changed"
        print("MODEL_USAGE_BOTH_MODELS_PASS:", json.dumps(counted, sort_keys=True))

    print("PASS: synthetic regression only; no AB30 completion or native deployment claimed")


if __name__ == "__main__":
    main()
