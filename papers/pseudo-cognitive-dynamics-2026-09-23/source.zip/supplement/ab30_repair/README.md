# AB30 analysis repair proposal

This package contains an additive, reviewable repair for the AB30 score aggregator. It does not modify the live campaign, launch a solver, complete or grade AB30, or establish a brain-on performance advantage. All regression data are synthetic. No held-out mathematical questions, expected answers, or answer keys are included.

## Source and exact defect

Repository: `<private-repo>`

Source path: `12_cognitive_architecture/brain_improvement/campaign_2026-09-23_ab30_tokens/tools/analyze.py`

Original Git blob: `0a1879f693f1512df9142db4bb483dc9d5949468` ([immutable Git object](https://api.github.com/repos/<private-repo>/git/blobs/0a1879f693f1512df9142db4bb483dc9d5949468)). The packaged `analyze.py` reproduces this object byte for byte: 10,959 bytes, SHA-256 `0f8341ab5fcd3008395ce8748fe8c9f423909b979d42a0b052b4e153727a7bd3`.

The `score()` function's family loop currently evaluates:

```python
for fam in sorted({r["family"] for r in res["items"]}) | {"all"}:
```

`sorted(...)` returns a list. Python does not define set union between that list and `{"all"}`, so the scoring path raises `TypeError: unsupported operand type(s) for |: 'list' and 'set'` before writing `RESULT.json`.

The proposed one-line correction performs set union first and sorts the resulting set:

```python
for fam in sorted({r["family"] for r in res["items"]} | {"all"}):
```

Every other byte is preserved. The corrected source has Git blob `0b7aed7387b17ce8cc329d105cee51e64657c567` and SHA-256 `da525b2d3727af18a470760a014150c52c5ac44f1c938df8b19c1de0cdf53a4e`.

## Contents

| File | Purpose |
|---|---|
| `analyze.py` | Exact original source, retaining the defect for reproduction |
| `analyze_corrected.py` | Original plus the single grouping-line correction |
| `ab30_grouping_fix.patch` | Unified patch using the repository-relative live source path |
| `reproduce_ab30_grouping.py` | Portable, standard-library-only synthetic regression |
| `regression_output.txt` | Output of the local successful regression run |
| `source_manifest.json` | Original and corrected source identities and patch digest |

## Reproduce without accessing the campaign

Python 3.9 or later is sufficient. From this directory, run:

```bash
python reproduce_ab30_grouping.py
```

The script can also be invoked by its path from any working directory. It resolves the analyzers relative to its own location, overrides their `RUNS` globals with a temporary directory, creates synthetic fixtures there, and removes all temporary inputs and outputs afterward. The original analyzers' Windows default path is preserved to keep the patch restricted to the defect; the regression never uses that path.

The regression checks:

1. The original bytes have the specified Git blob identity and the corrected file differs only by the intended line.
2. The original `score()` raises the expected list/set `TypeError` and does not write results.
3. The fixed `score()` aggregates three synthetic pairs across two families, covering a win, a loss, and a tie, and writes both family-level and `all` results.
4. Existing `tok()` behavior sums both synthetic `modelUsage` entries and takes them in preference to a deliberately conflicting final-call `usage` block. The expected totals are input 7, cache-read 30, cache-write 10, output 12, and thinking 3. These are fixture values, not measured AB30 costs. This accounting function is not changed by the patch.

Expected last line:

```text
PASS: synthetic regression only; no AB30 completion or native deployment claimed
```

## Handoff to the connected Claude worker

This is a repair proposal for review. The native campaign lease required for a live edit was unavailable to the preparing session, so no remote live AB30 file was edited. The connected worker should follow the campaign's current lease and control protocol, inspect the current source, and confirm that the one-line correction remains applicable before modifying the active analyzer. If the source has changed, preserve those changes and adapt the correction after review. Do not replace a newer analyzer wholesale with this historical copy.

Once an appropriately authorized worker holds the required native lease, the patch can be checked from the repository root with `git apply --check` against the supplied patch path. That check and any subsequent live application are not performed or claimed by this package. Existing real run records, blind-grading separation, and campaign history must be retained.

## Separate evaluation considerations

The correction removes one deterministic analysis crash. It does not resolve broader experiment-design questions. The paper and the campaign's final analysis still need to distinguish completed pairs from the intended cohort, explain missing or excluded attempts, record the brain version and live hook changes for each pair, and interpret wall time in light of machine saturation and the documented priority change. The inspected campaign documents describe live intervention changes and a stopped web-access pilot; their effects require reporting and design judgment, not an additional speculative code patch here.

Specific checks for the campaign's eventual analysis are:

- The off arm's safe mode disables automatic context and hooks but does not, by itself, prevent access to local files through its remaining tools. Inspect read/tool traces before treating it as an information-isolated control.
- The on arm includes general startup documents and hooks alongside Math Brain. A bundled-brain comparison does not identify the marginal effect of a math-only component without an additional ablation.
- `tokens()` summarizes successful runs. Report costs of all attempts, including excluded pilots, failures, and retries, separately from costs of completed eligible pairs.
- `score()` skips missing pairs and overwrites duplicate grades keyed by item and arm. Validate the preregistered cohort, duplicates, missing results, and missing grades before interpreting its aggregates.
- `score()` does not itself consume `AUDIT.json`. A missing contamination audit must not be treated as a clean run; apply the declared audit and exclusion procedure separately.
- The fallback `usage` block need not be cumulative for every execution pattern. Missing cumulative usage and missing token components need an explicit accounting limitation; thinking tokens must not be added again if already contained in output.
- The exact sign-test function rounds to five decimal places, so a small positive probability may display as zero. A publication should preserve sufficient precision without describing a rounded zero as an impossible event.

These observations are grounded in the [source analyzer](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/brain_improvement/campaign_2026-09-23_ab30_tokens/tools/analyze.py), [preregistration](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/brain_improvement/campaign_2026-09-23_ab30_tokens/PREREG.md), and [deviation record](https://github.com/<private-repo>/blob/bcff9346b68959f4cf330fdf9ca0e64a21c77d3e/12_cognitive_architecture/brain_improvement/campaign_2026-09-23_ab30_tokens/DEVIATION.md). They are not implemented changes in this one-line repair.

Successful synthetic aggregation establishes neither completion of the thirty pairs nor valid blind grades, uncontaminated sessions, real token totals, or a causal effect of Math Brain. Those claims require the campaign's actual records and planned analysis.
