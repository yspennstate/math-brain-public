#!/usr/bin/env python3
"""Recompute the public-facing, aggregate usage checks without private transcripts.

Run:
    python recompute_usage.py
    python recompute_usage.py --data-dir /path/to/supplement

Inputs contain daily aggregates, an anonymous histogram, and reported summary
metadata. No session identifiers, project directories, or prompt/response text
are needed. The histogram is derived from half_hours.tsv at the pinned commit.
This verifier does not recreate message-level deduplication or validate provider
billing. It cannot recover construction-only or all-time Math Brain costs.

Source commit: bcff9346b68959f4cf330fdf9ca0e64a21c77d3e
Repository: <private-repo>
Source folder: 12_cognitive_architecture/usage_ledger
"""

import argparse
import csv
import hashlib
import json
from pathlib import Path

FIELDS = ("input", "cache_read", "cache_create", "output")
DAILY_BLOB_SHA = "987b9ed700cb7c5adadcae85a7ebe1b703751e04"
DAILY_COLUMNS = (
    "day_utc", "sessions", "msgs", "input", "cache_read",
    "cache_create", "output", "max_session_output",
)
HISTOGRAM_COLUMNS = ("output_tokens", "bucket_count")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_table(path, columns):
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        require(tuple(reader.fieldnames or ()) == columns,
                f"Unexpected columns in {path.name}")
        result = list(reader)
    require(bool(result), f"Empty table: {path.name}")
    require(all(None not in row and None not in row.values() for row in result),
            f"Malformed row in {path.name}")
    return result


def nonnegative_integer(value, label):
    number = int(value)
    require(number >= 0 and str(number) == value,
            f"Expected canonical nonnegative integer for {label}")
    return number


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--data-dir", type=Path, default=Path(__file__).resolve().parent,
        help="Directory containing the sanitized supplement files",
    )
    args = parser.parse_args()
    root = args.data_dir
    daily_path = root / "daily_usage.tsv"
    data = daily_path.read_bytes()
    git_blob_sha = hashlib.sha1(
        b"blob " + str(len(data)).encode("ascii") + b"\0" + data
    ).hexdigest()
    require(git_blob_sha == DAILY_BLOB_SHA,
            "Daily aggregate file does not match the pinned Git blob")

    daily = read_table(daily_path, DAILY_COLUMNS)
    for row in daily:
        for key in DAILY_COLUMNS[1:]:
            row[key] = nonnegative_integer(row[key], f"daily {key}")
    dates = [row["day_utc"] for row in daily]
    require(dates == sorted(set(dates)), "Daily dates must be unique and ordered")
    expected = json.loads((root / "token_summary.json").read_text("utf-8"))
    require(dates[0] == expected["first"][:10], "First date mismatch")
    require(dates[-1] == expected["last"][:10], "Last date mismatch")
    require(len(dates) == 32, "Expected 32 recorded UTC dates")

    totals = {key: sum(row[key] for row in daily) for key in FIELDS}
    for key in FIELDS:
        require(totals[key] == expected["total"][key],
                f"Daily total mismatch for {key}")
    messages = sum(row["msgs"] for row in daily)
    require(messages == expected["total"]["msgs"], "Usage-message mismatch")
    require(sum(totals.values()) == expected["total"]["four_fields"],
            "Four-field sum mismatch")

    hist = read_table(root / "half_hour_output_histogram.tsv", HISTOGRAM_COLUMNS)
    for row in hist:
        for key in HISTOGRAM_COLUMNS:
            row[key] = nonnegative_integer(row[key], f"histogram {key}")
        require(row["bucket_count"] > 0, "Histogram frequencies must be positive")
    outputs = [row["output_tokens"] for row in hist]
    require(outputs == sorted(set(outputs)),
            "Histogram outputs must be unique and ordered")
    all_buckets = sum(row["bucket_count"] for row in hist)
    positive_buckets = sum(
        row["bucket_count"] for row in hist if row["output_tokens"] > 0
    )
    threshold = expected["cap"]["threshold"]
    above = sum(
        row["bucket_count"] for row in hist if row["output_tokens"] > threshold
    )
    equal = sum(
        row["bucket_count"] for row in hist if row["output_tokens"] == threshold
    )
    output_from_hist = sum(
        row["output_tokens"] * row["bucket_count"] for row in hist
    )
    require(output_from_hist == totals["output"],
            "Histogram output does not match daily output")
    for key, observed in (
        ("all_buckets", all_buckets),
        ("positive_buckets", positive_buckets),
        ("above_threshold", above),
    ):
        require(observed == expected["cap"][key], f"Cap summary mismatch: {key}")

    report = {
        "verification": "PASS",
        "scope": expected["scope"],
        "pinned_commit": expected["snapshot"],
        "daily_git_blob_sha_verified": git_blob_sha,
        "recorded_dates": len(dates),
        "first_day_utc": dates[0],
        "last_day_utc": dates[-1],
        "usage_messages": messages,
        "daily_active_session_counts_sum_not_distinct_sessions": sum(
            row["sessions"] for row in daily
        ),
        "usage_totals": totals,
        "input_including_cache": sum(totals[key] for key in FIELDS[:-1]),
        "four_field_sum": sum(totals.values()),
        "cache_read_share_of_four_field_events": (
            totals["cache_read"] / sum(totals.values())
        ),
        "half_hour_cap_check": {
            "threshold_output_tokens": threshold,
            "all_buckets": all_buckets,
            "positive_output_buckets": positive_buckets,
            "above_threshold": above,
            "equal_to_threshold": equal,
            "fraction_of_all_buckets": above / all_buckets,
            "fraction_of_positive_output_buckets": above / positive_buckets,
            "max_bucket_output": max(outputs),
            "output_sum_matches_daily": True,
        },
        "not_recomputed_from_sanitized_inputs": [
            "Distinct session count and session-specific date endpoints",
            "Working-directory attribution and dominant-model labels",
            "Original transcript completeness or message deduplication",
            "Provider bills, construction-only costs, all-time costs",
        ],
    }
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

