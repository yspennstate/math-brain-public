R17 C045 artifact bundle for 20260918_0900Z_cap7six_c045_f2a1.
All theorem-facing finite checks are exact except power_search, which is explicitly search-only.
Regenerate in order: language_checker -> generated /mnt/data/c045_dfa.h; compile product_generator with -I/mnt/data -> product table; run power_search -> witness; run exact_cone_checker -> exact cone; run endpoint_checker.py.
The full_count_checker independently scans all 30^6 six-factor words and confirms the new minimal-deficiency count.
Large generated DFA header, product table, and witness are omitted; byte counts/SHA-256 hashes are in large_intermediate_hashes.out.
