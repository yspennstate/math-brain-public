#include <bits/stdc++.h>
#include <omp.h>
using namespace std;
struct Fac { uint64_t a=0,b=0; uint8_t al=0,bl=0; };
static Fac F[30];
static void initF(){
 for(int z=0;z<30;z++){int c=z/15,l=z%15-7,b=1-c; Fac f; int pa=0,pb=0;
   auto pusha=[&](int x){ if(x) f.a|=1ULL<<pa; pa++; };
   auto pushb=[&](int x){ if(x) f.b|=1ULL<<pb; pb++; };
   if(l>=0){for(int i=0;i<l;i++) pusha(b); pusha(c); pushb(c);} else {pusha(c); for(int i=0;i<-l;i++) pushb(b); pushb(c);} f.al=pa;f.bl=pb;F[z]=f;
 }
}
static inline bool def_word(const uint8_t*w,int r){uint64_t A=0,B=0;int al=0,bl=0;for(int i=0;i<r;i++){auto &f=F[w[i]];A|=f.a<<al;B|=f.b<<bl;al+=f.al;bl+=f.bl;}uint64_t full=(bl==64?~0ULL:((1ULL<<bl)-1)),m1=B,m0=(~B)&full,S=0;for(int i=0;i<al;i++){uint64_t m=((A>>i)&1)?m1:m0;uint64_t x=m|S,y=(S<<1)|1;S=x&~(x-y);}return __builtin_popcountll(S)>r;}
struct Bits{vector<uint64_t>v;Bits(){}Bits(uint64_t n):v((n+63)/64){}inline void set(uint64_t i){v[i>>6]|=1ULL<<(i&63);}inline bool get(uint64_t i)const{return (v[i>>6]>>(i&63))&1;}};
int main(){initF(); omp_set_num_threads(min(5,omp_get_max_threads())); const int K=30; uint8_t amap[K]; int kk=0; for(int c=0;c<2;c++) for(int l=-7;l<=7;l++) amap[kk++]=c*15+(l+7);
 uint64_t pK[7]={1};for(int r=1;r<=6;r++)pK[r]=pK[r-1]*K;
 Bits D5(pK[5]);
#pragma omp parallel for schedule(static)
 for(long long cc=0;cc<(long long)pK[5];cc++){uint64_t q=cc;uint8_t w[5];for(int i=4;i>=0;i--){w[i]=amap[q%K];q/=K;}if(def_word(w,5))D5.set(cc);} 
 cerr<<"D5 done total="<<pK[5]<<"\n";
 unsigned long long safe5=0; for(uint64_t c=0;c<pK[5];++c) if(!D5.get(c)) safe5++; cerr<<"safe5="<<safe5<<"\n";
 // Direct full scan for independent count.
 uint64_t end=pK[6]; unsigned long long total=0, candidates=0; double t=omp_get_wtime();
#pragma omp parallel for reduction(+:total,candidates) schedule(dynamic,4096)
 for(long long cc=0; cc<(long long)end; ++cc){uint64_t code=(uint64_t)cc; uint64_t pref=code/K, suf=code%pK[5]; if(D5.get(pref)||D5.get(suf)) continue; candidates++; uint64_t q=code; uint8_t w[6]; for(int i=5;i>=0;i--){w[i]=amap[q%K];q/=K;} if(def_word(w,6)) total++; }
 cout<<"K="<<K<<" total_words="<<pK[6]<<" full_scanned="<<end<<" candidate_full="<<candidates<<" minimal_deficient_full="<<total<<" full_direct="<<total<<" seconds="<<(omp_get_wtime()-t)<<"\n";
}
