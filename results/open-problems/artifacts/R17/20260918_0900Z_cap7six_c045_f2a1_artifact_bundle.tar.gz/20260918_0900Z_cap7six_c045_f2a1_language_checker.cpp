#include <bits/stdc++.h>
#include <omp.h>
using namespace std;
struct Fac { uint64_t a=0,b=0; uint8_t al=0,bl=0; };
static Fac F[30];
static void initF(){
 for(int z=0;z<30;z++){int c=z/15,l=z%15-7,b=1-c; Fac f; int pa=0,pb=0;
   auto pusha=[&](int x){ if(x) f.a|=1ULL<<pa; pa++; };
   auto pushb=[&](int x){ if(x) f.b|=1ULL<<pb; pb++; };
   if(l>=0){for(int i=0;i<l;i++) pusha(b); pusha(c); pushb(c);} else {pusha(c); for(int i=0;i<-l;i++) pushb(b); pushb(c);} f.al=pa;f.bl=pb;F[z]=f;
 }
}
static inline bool def_word(const uint8_t*w,int r){uint64_t A=0,B=0;int al=0,bl=0;for(int i=0;i<r;i++){auto &f=F[w[i]];A|=f.a<<al;B|=f.b<<bl;al+=f.al;bl+=f.bl;}uint64_t full=(bl==64?~0ULL:((1ULL<<bl)-1)),m1=B,m0=(~B)&full,S=0;for(int i=0;i<al;i++){uint64_t m=((A>>i)&1)?m1:m0;uint64_t x=m|S,y=(S<<1)|1;S=x&~(x-y);}return __builtin_popcountll(S)>r;}
struct Bits{vector<uint64_t>v;Bits(){}Bits(uint64_t n):v((n+63)/64){}inline void set(uint64_t i){v[i>>6]|=1ULL<<(i&63);}inline bool get(uint64_t i)const{return (v[i>>6]>>(i&63))&1;}};
struct Node{array<int,30> nx;int fail=0;bool out=false;int par=-1;uint8_t pch=0;Node(){nx.fill(-1);}};
struct AH{size_t operator()(array<int,31>const&a)const noexcept{uint64_t h=1469598103934665603ULL;for(int x:a){h^=(uint32_t)(x+0x9e3779b9);h*=1099511628211ULL;}return h;}};
static vector<uint8_t> compw(vector<uint8_t>w){for(auto&z:w){int c=z/15,l=int(z%15)-7;z=(1-c)*15+l+7;}return w;}
static vector<uint8_t> swapw(vector<uint8_t>w){for(auto&z:w){int c=z/15,l=int(z%15)-7;z=c*15+(-l)+7;}return w;}
int main(){initF(); omp_set_num_threads(min(5,omp_get_max_threads()));
 const int A=30,K=30; uint64_t pA[7]={1};for(int r=1;r<=6;r++)pA[r]=pA[r-1]*A;
 vector<Bits>D(6); for(int r=2;r<=5;r++){D[r]=Bits(pA[r]);
#pragma omp parallel for schedule(static)
  for(long long cc=0;cc<(long long)pA[r];cc++){uint64_t q=cc;uint8_t w[5];for(int i=r-1;i>=0;i--){w[i]=q%A;q/=A;}if(def_word(w,r))D[r].set(cc);} cerr<<"D"<<r<<" done\n";}
 vector<pair<uint8_t,uint64_t>> base; uint64_t cnt[7]={0};
 for(int r=2;r<=5;r++){for(uint64_t code=0;code<pA[r];code++)if(D[r].get(code)){bool minv=true;if(r>2){uint64_t pref=code/A,suf=code%pA[r-1];if(D[r-1].get(pref)||D[r-1].get(suf))minv=false;}if(minv){cnt[r]++;base.push_back({(uint8_t)r,code});}}}
 cerr<<"base counts actual30 "<<cnt[2]<<" "<<cnt[3]<<" "<<cnt[4]<<" "<<cnt[5]<<" total="<<base.size()<<"\n";
 // complete six-factor cap-7 alphabet: K=A=30 actual symbols; enumerate one free complement half then add complements.
 uint8_t amap[K];int kk=0;for(int c=0;c<2;c++)for(int l=-7;l<=7;l++)amap[kk++]=c*15+(l+7);
 uint64_t pK[7]={1};for(int r=1;r<=6;r++)pK[r]=pK[r-1]*K; Bits D5s(pK[5]);
#pragma omp parallel for schedule(static)
 for(long long cc=0;cc<(long long)pK[5];cc++){uint64_t q=cc;uint8_t w[5];for(int i=4;i>=0;i--){w[i]=amap[q%K];q/=K;}if(def_word(w,5))D5s.set(cc);} cerr<<"D5 shell done\n";
 vector<uint64_t> half; half.reserve(3500000); // first symbol c=0 gives exact complement representatives
 uint64_t end=15*pK[5];
#pragma omp parallel
 {vector<uint64_t> loc;loc.reserve(800000);
#pragma omp for schedule(dynamic,4096)
 for(long long cc=0;cc<(long long)end;cc++){uint64_t code=(uint64_t)cc,pref=code/K,suf=code%pK[5];if(D5s.get(pref)||D5s.get(suf))continue;uint64_t q=code;uint8_t w[6];for(int i=5;i>=0;i--){w[i]=amap[q%K];q/=K;}if(def_word(w,6))loc.push_back(code);} 
#pragma omp critical
 half.insert(half.end(),loc.begin(),loc.end()); }
 sort(half.begin(),half.end()); cnt[6]=2ULL*half.size(); cerr<<"min6 shell="<<cnt[6]<<" half="<<half.size()<<"\n";
 size_t totalp=base.size()+cnt[6]; vector<Node>nd; nd.reserve(totalp*2+1); nd.emplace_back();
 auto insertw=[&](const uint8_t*w,int r){int q=0;for(int i=0;i<r;i++){int a=w[i];if(nd[q].nx[a]<0){nd[q].nx[a]=nd.size();nd.emplace_back();nd.back().par=q;nd.back().pch=a;}q=nd[q].nx[a];}nd[q].out=true;};
 for(auto [r,code]:base){uint8_t w[6];for(int i=r-1;i>=0;i--){w[i]=code%A;code/=A;}insertw(w,r);} 
 for(uint64_t code:half){uint8_t w[6],wc[6];uint64_t q=code;for(int i=5;i>=0;i--){int k=q%K;q/=K;w[i]=amap[k];int c=w[i]/15,l=w[i]%15-7;wc[i]=(1-c)*15+l+7;}insertw(w,6);insertw(wc,6);} cerr<<"trie nodes="<<nd.size()<<"\n";
 queue<int>qu;for(int a=0;a<A;a++){int q=nd[0].nx[a];if(q>=0)qu.push(q);else nd[0].nx[a]=0;}while(!qu.empty()){int r=qu.front();qu.pop();nd[r].out|=nd[nd[r].fail].out;for(int a=0;a<A;a++){int s=nd[r].nx[a];if(s>=0){nd[s].fail=nd[nd[r].fail].nx[a];qu.push(s);}else nd[r].nx[a]=nd[nd[r].fail].nx[a];}}
 vector<int>safe,si(nd.size(),-1);safe.reserve(nd.size());for(int q=0;q<(int)nd.size();q++)if(!nd[q].out){si[q]=safe.size();safe.push_back(q);}int sink=safe.size(),N=sink+1;cerr<<"safe="<<sink<<"\n";
 vector<array<int,30>>T(N);for(int i=0;i<sink;i++){int q=safe[i];for(int a=0;a<A;a++){int r=nd[q].nx[a];T[i][a]=nd[r].out?sink:si[r];}}T[sink].fill(sink);vector<int>cls(N);cls[sink]=1;int oldk=2;
 while(1){unordered_map<array<int,31>,int,AH>M;M.reserve((size_t)N*2);vector<int>nc(N);int k=0;for(int q=0;q<N;q++){array<int,31>s;s[0]=(q==sink);for(int a=0;a<A;a++)s[a+1]=cls[T[q][a]];auto[it,ins]=M.emplace(s,k);if(ins)k++;nc[q]=it->second;}cls.swap(nc);cerr<<"classes="<<k<<"\n";if(k==oldk)break;oldk=k;}
 int classes=*max_element(cls.begin(),cls.end())+1,sinkc=cls[sink];vector<int>cmap(classes,-1),rep(classes,-1);int dk=0;for(int c=0;c<classes;c++)if(c!=sinkc)cmap[c]=dk++;for(int q=0;q<sink;q++)if(rep[cls[q]]<0)rep[cls[q]]=q;vector<array<int32_t,30>>TR(dk);for(int c=0;c<classes;c++)if(c!=sinkc){int i=cmap[c],q=rep[c];for(int a=0;a<A;a++){int cc=cls[T[q][a]];TR[i][a]=(cc==sinkc)?-1:cmap[cc];}}int START=cmap[cls[si[0]]];
 auto wordOf=[&](int safidx){int node=safe[safidx];vector<uint8_t>w;while(node){w.push_back(nd[node].pch);node=nd[node].par;}reverse(w.begin(),w.end());return w;};auto walk=[&](const vector<uint8_t>&w){int q=0;for(auto a:w)q=nd[q].nx[a];return q;};vector<uint32_t>CM(dk),SM(dk);for(int c=0;c<classes;c++)if(c!=sinkc){int i=cmap[c];auto ww=wordOf(rep[c]);int qc=walk(compw(ww)),qs=walk(swapw(ww));if(nd[qc].out||nd[qs].out){cerr<<"auto reject\n";return 5;}CM[i]=cmap[cls[si[qc]]];SM[i]=cmap[cls[si[qs]]];}
 for(int i=0;i<dk;i++){if(CM[CM[i]]!=(uint32_t)i||SM[SM[i]]!=(uint32_t)i||CM[SM[i]]!=SM[CM[i]]){cerr<<"involution fail\n";return 6;}for(int a=0;a<A;a++){int c=a/15,l=a%15-7,ac=(1-c)*15+l+7,as=c*15+(-l)+7;int t=TR[i][a],tc=TR[CM[i]][ac],ts=TR[SM[i]][as];if(!((t<0&&tc<0)||(t>=0&&tc==(int)CM[t]))||!((t<0&&ts<0)||(t>=0&&ts==(int)SM[t]))){cerr<<"equiv fail i="<<i<<" a="<<a<<"\n";return 7;}}}
 cout<<"R17 C045 complete actual-30 six-factor cap-7 language\nbase2="<<cnt[2]<<" base3="<<cnt[3]<<" base4="<<cnt[4]<<" base5="<<cnt[5]<<" base_total="<<base.size()<<"\ncomplete_minimal_deficient_six="<<cnt[6]<<" complement_orbit_representatives="<<half.size()<<" patterns_total="<<totalp<<"\naho_nodes="<<nd.size()<<" safe_aho_nodes="<<safe.size()<<" minimized_nonrejecting_states="<<dk<<" start="<<START<<"\nEXACT_COMPLETE_MIN6_COUNT_PASS\nEXACT_SYMMETRY_CLOSURE_PASS\nEXACT_DFA_MINIMIZATION_PASS\nALL_EXACT_CHECKS_PASS\n";
 ofstream f("/mnt/data/c045_dfa.h");f<<"#pragma once\nstatic constexpr int DFAK="<<dk<<",DFAAL=30,DFASTART="<<START<<";\nstatic const int32_t DFATR[DFAK][DFAAL]={\n";for(auto&r:TR){f<<"{";for(int a=0;a<A;a++){if(a)f<<',';f<<r[a];}f<<"},\n";}f<<"};\nstatic const uint32_t DFACM[DFAK]={";for(int i=0;i<dk;i++){if(i)f<<',';f<<CM[i];}f<<"};\n";
}
