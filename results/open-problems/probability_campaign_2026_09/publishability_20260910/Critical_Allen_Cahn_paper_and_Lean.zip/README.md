# Critical Allen–Cahn endpoint counterexample

Selected probability-bank candidates: P0266/P0267 (one construction, two questions).

- paper.pdf: complete eight-page research manuscript, visually reviewed.
- paper.tex: editable LaTeX source.
- EndpointCore.lean: nine compiled measure-theoretic/algebraic components.
- FORMALIZATION.md: detailed correspondence and unfinished stochastic obligations.

The full stochastic Lean proof is not complete. The handwritten mathematical argument survived two derivations and source-hypothesis checks. Publication potential: a credible short specialist note if new; novelty has not been certified.

The canonical assessment is ~/<private-repo>/12_cognitive_architecture/audits/reports/2026/09/10/probability_publishability/REVIEW.md. Build receipts and proof evidence are under ~/<private-repo>/12_cognitive_architecture/audits/probability_publishability_20260910/.

No journal submission or author email was sent. These are local review artifacts.
