# Bounded Densities of Quadratic Forms under Product Measures

Anonymous research manuscript, 23 September 2026. The PDF has an abstract and an empty author field. The full unrestricted three-eigenvalue problem remains **OPEN**.

## Files

- `main.tex` is the master document. All included `.tex` chapters are required.
- `bibliography.bib` contains the checked references. `main.bbl` is supplied for convenient compilation.
- `build.py` runs PDFLaTeX, BibTeX, and two further PDFLaTeX passes.
- The PDF is distributed separately as `Bounded_Densities_of_Quadratic_Forms.pdf`.
- `LITERATURE_AUDIT.md`, `FLEET_COVERAGE_AUDIT.md`, `fleet_catalogue.json`, and the chapter provenance files distinguish manuscript proofs from archived source claims and record corrections.

This source package can be imported directly into Overleaf with `main.tex` as the main document. It requires standard LaTeX packages only and no shell escape.

## What is proved

The manuscript supplies complete arguments for its theorem statements, including the arbitrary-rank semidefinite theorem, fixed-dimensional bounds for every signature, coordinate-pair and rank-two potential estimates, volume and regularized-determinant Fourier estimates, no-pivot reductions, lower-order integrability, grouped and single-hub estimates, and additional coordinate stability results. The full Gaussian-mixture theorem applies to arbitrary matrices and affine terms under a precise component-peak condition; it gives a universal constant below three for centered cap-one Gaussian scale mixtures. This does not extend to arbitrary rough cap-one laws merely by Gaussian-mixture approximation.

Classical theorems used as inputs are cited at the point of use. The independent proof checks are separate mathematical derivations within this research session; they are not external journal peer review or a machine-checked formalization. Numerical values and exploratory scripts are not used as substitutes for proofs.

## Source scope and correction policy

The original project files remain in the private `math-open-problems` repository. The supplementary research archive preserves all 341 files in the interactive source tree at the initial snapshot, 153 recent fleet reports selected by run timestamp, later specifically read sources, the full source-tree inventory, and new proof notes. It does not claim that every historical operational report has been independently proved. Repeated and weaker variants are represented by their stronger manuscript theorems where valid. The catalogue records source-specific conditional claims and flags unsupported deductions.

The initial source snapshot is `36d0dc0c4ac0910e8d84ae64d443136df86242d5`. Later reads have their own immutable source metadata. The original sources may contain superseded constants and incorrect claimed implications; the manuscript and correction ledger control the mathematical assertions in this release.

Notable corrections include the distinction between an interval profile and a profile for arbitrary Borel sets, replacing a skeleton identity by the valid inequality when singular minors occur, using the diagonal of `|A|` rather than the absolute values of the diagonal entries in the indefinite spread theorem, and retaining the exact mixture-moment hypothesis in Gaussian-mixture arguments.

## Rebuild

Run `python build.py` in this directory, or compile `main.tex` with PDFLaTeX, run BibTeX on `main`, then compile twice more. A successful build should have no undefined references or citations and no overfull boxes. Read `VALIDATION.md` for the checks performed on the delivered release.
