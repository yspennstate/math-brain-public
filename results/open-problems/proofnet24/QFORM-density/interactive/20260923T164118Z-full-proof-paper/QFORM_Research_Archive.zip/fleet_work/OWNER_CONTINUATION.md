# Owner continuation: all eighty existing workers remain on the full QFORM problem

Request QFORM-EXCLUSIVE-SIGNIN-20260923T164448Z. Issued by the interactive coordinator under the current owner's explicit request to ensure the scheduled tasks are signing in, remain exclusively on this problem, publish useful work to GitHub, and continue toward the full proof. This is an owner continuation, not a worker sign-in or a statement that all eighty have acknowledged it. Later direct owner/platform instructions and stops prevail.

## Required action at the next actual invocation or control refresh

Every existing fleet01-fleet04/B01-B20 slot keeps QFORM-DENSITY-3EIG-20260922 as its sole mathematical target. Preserve the current differentiated assignment and designated partner. Do not return to FEI, other open problems, the novel, installation, or benchmarks. The interactive parent is preparing an anonymous manuscript separately; the eighty research slots continue mathematical proof work.

At the beginning of your next real run, post your own actual-time line:
`SIGNED IN - working on the quadratic-form bounded-density conjecture (universal constant), account <fleet01..fleet04>, slot <B01..B20>, <actual UTC time>.`
Then identify the exact unproved implication you attack and acknowledge QFORM-EXCLUSIVE-SIGNIN-20260923T164448Z in your own normal immutable run/handoff record. Keep any already-existing same-hour canonical login; do not overwrite it or backdate a new one. Keep confirmation to a few lines and continue substantive mathematics immediately. Never create acknowledgements for other workers or count this published request as their adoption.

Save an early substantive calculation, then the completed proof or precise remaining gap, in your own canonical math-open-problems QFORM fleet path before ending. A sign-in is not the calculation. Provide the actual commit, path, hypotheses and a peer result used at an equation; read back the result. If a write actually fails, report the actual error and preserve the calculation in your own authorized brain recovery path or ordinary task output. Do not infer or invent an error, and do not bypass access controls.

## Source refresh: follow the continuation, not only yesterday's directory

Resolve fresh branch heads in BOTH repositories at each actual source refresh. Read current AGENTS.md, scheduled_tasks/README.md, correction events, MEMORY_PROTOCOL and your assignment. Read the current Claude continuation at
`math-open-problems:proofnet24/QFORM-density/interactive/20260922T231000Z-semidefinite-and-hub-reduction/README.md`
and the exact relevant report beneath it. The most recent Claude-attributed commit specifically verified in this continuation is `c4c23b784395630c094ba299a50712209921d1ae` (23 September, 16:22:28 UTC), “hub that sees P”; its README blob is `a1bd502b92b5d06c37b6a909e143b56932df99ad`. It updates the single-hub conditional-adaptation proposal (SP), which is an OPEN proposed estimate, not a proved solution.

The old directory `20260922T211500Z-decoupling-brascamp-lieb/` now points to that continuation. Its 01:00:46 commit `7ffd1ed79398611eb06752f622be0ce33dcacb5a` is NOT the newest Claude work. Check the actual continuation path history and fresh branch tree, not search indexing or only the older path. Preserve the earlier source-specific review and all corrections.

Apply the newest relevant completed peer report after checking its exact hypotheses. Concrete recent inputs include:
- `c6f29397b3d45a7cf7ab67633a5451767b478912`, fleet04/B20 `20260923T142031Z-fleet04-B20-QFORM-r10/REPORT.md`: under small physical diagonals, a coordinate cut has Frobenius energy >11907/16384; fifth-volume estimates reduce the complement to concentrated top-four cross energy.
- `5d0600968569ced59d5a9efe08311ae656debed6`, fleet03/B20 `20260923T154628Z-fleet03-B20-QFORM-auto11/REPORT.md`: within the aligned STAR4 chamber, transverse self action or a rank-at-most-five carrier with third singular value >0.7985866 and a retained non-diagonal residual. This chamber is not the whole remaining conjecture.
- `20ec5f8f3ed2028edf27894cd3956d13e4662a9a`, fleet02/B20 `20260923T155833Z-fleet02-B20-QFORM-auto11c/`: sharper entire-tail bounds and an exact obstruction to promoting half-Riesz credit alone to bounded density. A third genuinely independent square gives a valid sufficient estimate; the actual coupled survivor does not supply that independence automatically.

These three fleet paths are beneath `proofnet24/QFORM-density/fleet-2026-09-22/<account>/B20/` in math-open-problems. They are inputs to check/apply, not an automatic endorsement of every borrowed analytic receiver. In particular, retain every row-marginal/leverage or grouped-source gate of a volume/Fourier theorem and verify the original source before using a abbreviated displayed formula.

## The mathematical target and current gaps

The full statement remains OPEN: for independent real probability densities <=1 and arbitrary symmetric A with at least three absolute eigenvalues >=1, prove a universal finite bound for the density of X^T A X, or a valid counterexample. Preserve arbitrary signs, affine terms arising from conditioning, unbounded/fragmented supports and all additional spectrum; continuity is separate.

Keep original-coordinate product provenance through the third smoothing resource. Live work includes the rough single-hub problem with a small spread coupling, the proposed (SP) conditional-adaptation estimate, nonzero near-null pivots, and low-rank/concentrated-volume configurations with arbitrary same-group curvature and non-diagonal residuals. Connect an actual uncovered configuration to a proved estimate. Small operator error is not a small random quadratic error without input moments. More precise matrix reductions help, but an unproved analytic passage must remain explicit.

Do not reuse the refuted arbitrary-joint coarea cap, conditional-density supremum shortcuts, independence after rotation, uniform pointwise quadratic-phase decay, or an asserted uniformly good single minor. Retain the rank-two logarithmic counterexample. Numerical evidence and source delivery are not universal proofs. A full candidate must cover every original quantifier and receive two actual independent complete reviews.

## Concrete delivery reconciliation

The accompanying [eighty-row evidence matrix](../events/interactive/20260923T164448Z-fleet-continuation/FLEET_EVIDENCE.json) records exact source-tree and blob hashes. In the bounded observation starting 16:39 UTC, 78 canonical mathematical artifacts were read, 77 with run paths dated today; 65 run paths were within the preceding three hours. These are artifact counts, not proved-theorem counts or a claim of eighty simultaneous active workers. All twenty directly exposed fleet04 tasks were enabled and exclusive-QFORM-directed with last-run timestamps 16:21-16:33 UTC. No other account's current native inventory was directly exposed.

Fleet04/B04 and B06 have real QFORM sign-in evidence and recent native runs, but no canonical QFORM mathematical slot tree or standard handoff tree was found in this snapshot. B04's explicit QFORM start is `476b42beea636c37af63c1be96c002649e36a97f` at 11:10:37 UTC; B06's QFORM login is `274728931a273e76227b61b388814fed373e46c5` at 02:13:20 UTC. These observations do not identify an outage or a cause. Those workers must preserve the next useful calculation promptly and name any actual alternate result or genuine failure. Fleet04/B20 reconciles these two specific gaps in its next normal brief keeper step, then returns to mathematics. Other B20 keepers review their own twenty rows and identify actual acknowledgements, results, source freshness and genuine missing evidence separately.

## Scheduling and delivery

No task creation, restart, enabled-state change, cadence change or cross-account authentication is requested. Native fleet04 prompts already require the mutable newest-Claude request, which now links to this continuation, so a native rewrite is unnecessary merely to deliver this refresh. Account-local B20 keepers retain their existing lease/inventory safeguards for any genuinely necessary authorized prompt repair and do not overwrite newer prompts with obsolete bundles. Preserve identities, hourly cadence, enabled/paused states, quiet delivery and all peer history. Email and push instructions remain OFF; no agent-generated messages or notifications. Notification settings unavailable through the exposed schema remain unverified, not guessed.

Most effort stays on mathematics. After three substantively unchanged attempts, change mechanism on this same target. A copied claim, repeated sign-in or larger commit count is not progress. Repository publication does not prove native learned-memory ingestion.

## New interactive proof checkpoint to consume

The interactive parent's new supporting proofs are now committed at `math-open-problems@4f92aeb74083c6f95cb314a11fed1b812eacef9a:proofnet24/QFORM-density/interactive/20260923T164118Z-full-proof-paper/NEW_PROJECTED_CROSSING.md`, blob `dc7e29c3ee746ebf2856aaa6866b4b16b9a04b9f`. Read the full hypotheses and proofs before use. The weighted-subset Fourier argument allows an arbitrary-rank projected crossing remainder with its volume row marginals <=1/2; it removes the earlier exact-rank-two restriction in that crossing estimate. The grouped-hub extension retains arbitrary internal hub functions by pushing a complex phase-weighted measure to the hub projection. Independent scope checks and broader source assessment remain distinct from full-target verification.

B01-B04 and B09-B12 apply this result to an ACTUAL surviving physical partition, checking the rank of M_J, the projected crossing volume and every row-marginal gate. B05-B08 and B13-B18 retain their differentiated geometric, structural and rough-law tasks; use the new theorem when it resolves the precise equation being attacked. B19/B20 incorporate only compatible proved implications in the assembly graph. Do not have all eighty duplicate an audit. The theorem does not show that every no-pivot matrix admits the required uniformly nondegenerate split, and its bound can still deteriorate for the small coupling in Q_eps. The full conjecture remains OPEN. Later source checkpoints and the anonymous manuscript will use the same interactive directory; do not count a paper draft as a completed full proof.

